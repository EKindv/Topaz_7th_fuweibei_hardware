#include "ctiic.h"
#include "I2C.h"
#include "fm33fk5xx_fl.h" 
#include "fm33fk5xx.h" 
		//���ݴ����ӿڶ���
		//FT_INT  		= PA5  �ж�
		//CT_IIC_SDA  = PA4  ���� ���\����
		//CT_IIC_SCL  = PA6  ʱ��
		//FT_RST 		  = PA7	 ��λ
//����I2C�ٶȵ���ʱ
void CT_Delay(void)
{
	FL_DelayUs(5);
} 
//���ݴ���оƬIIC�ӿڳ�ʼ��
void CT_IIC_Init(void)
{					     
    FL_GPIO_InitTypeDef    GPIO_InitStruct;

    FL_I2C_MasterMode_InitTypeDef    defaultInitStruct;

    GPIO_InitStruct.pin = FL_GPIO_PIN_8;                                     /*??GPIO????*/
    GPIO_InitStruct.mode = FL_GPIO_MODE_DIGITAL;                                /*??GPIO?????*/
    GPIO_InitStruct.outputType = FL_GPIO_OUTPUT_OPENDRAIN;                       /*??GPIO?????*/
    GPIO_InitStruct.pull = FL_GPIO_BOTH_DISABLE;                                /*??GPIO??????*/
    GPIO_InitStruct.remapPin = FL_GPIO_PINREMAP_FUNCTON3;                       /*??GPIO???????*/
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;                   /*??GPIO????*/
    GPIO_InitStruct.analogSwitch = FL_DISABLE;                                  /*??GPIO??????*/
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);                                /*GPIO???*/
	
    GPIO_InitStruct.pin = FL_GPIO_PIN_15;                                     /*??GPIO????*/
    GPIO_InitStruct.mode = FL_GPIO_MODE_DIGITAL;                                /*??GPIO?????*/
    GPIO_InitStruct.outputType = FL_GPIO_OUTPUT_OPENDRAIN;                       /*??GPIO?????*/
    GPIO_InitStruct.pull = FL_GPIO_BOTH_DISABLE;                                /*??GPIO??????*/
    GPIO_InitStruct.remapPin = FL_GPIO_PINREMAP_FUNCTON3;                       /*??GPIO???????*/
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;                   /*??GPIO????*/
    GPIO_InitStruct.analogSwitch = FL_DISABLE;                                  /*??GPIO??????*/
	
    (void)FL_GPIO_Init(GPIOB, &GPIO_InitStruct); 
    defaultInitStruct.baudRate = 40000U;		/*I2C?????*/

}
//����IIC��ʼ�ź�
void CT_IIC_Start(void)
{
	I2C_Send_Bit(I2C1,STARTBIT);
}	  
//����IICֹͣ�ź�
void CT_IIC_Stop(void)
{
	I2C_Send_Bit(I2C1,STOPBIT);
}
//�ȴ�Ӧ���źŵ���
//����ֵ��1������Ӧ��ʧ��
//        0������Ӧ��ɹ�
uint8_t CT_IIC_Wait_Ack(void)
{
	return HW_I2C_Wait_Ack(I2C1, 250);  
} 
//����ACKӦ��
void CT_IIC_Ack(void)
{
	HW_I2C_Ack(I2C1);
}
//������ACKӦ��		    
void CT_IIC_NAck(void)
{
	HW_I2C_NAck(I2C1);
}					 				     
//IIC����һ���ֽ�
//���شӻ�����Ӧ��
//1����Ӧ��
//0����Ӧ��			  
void CT_IIC_Send_Byte(uint8_t txd)
{                        
	I2C_Send_Byte(I2C1,txd);
} 	    
//��1���ֽڣ�ack=1ʱ������ACK��ack=0������nACK   
uint8_t CT_IIC_Read_Byte(unsigned char ack)
{
    uint8_t receive = 0;

    if(I2C_Receive_Byte(I2C1, &receive) != 0)
    {
        return 0xFF; 
    }

    if(ack)
    {
        HW_I2C_Ack(I2C1);
    }
    else
    {
        HW_I2C_NAck(I2C1); 
    }
    
		return receive;  

}

/**
  * @brief  ??FT6336?????
  * @param  devAddr: ????(7?)
  * @param  regAddr: ?????
  * @retval ????(0xFF????)
  */

uint8_t i2c_read(I2C_Type *I2Cx, uint8_t devAddr, uint8_t regAddr)
{
    uint8_t data = 0xFF;
    uint32_t counter = 0;
    
    /****** ????? ******/
    FL_I2C_Master_EnableI2CStart(I2Cx); // ??START
    while(!FL_I2C_Master_IsActiveFlag_Start(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT) return 0xFF;

    /****** ??????+? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, (devAddr << 1) | 0x00); // ???
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ??????? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, regAddr);
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ?????? ******/
    FL_I2C_Master_EnableI2CRestart(I2Cx); // RESTART
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_Start(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT) return 0xFF;

    /****** ??????+? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, (devAddr << 1) | 0x01); // ???
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ???? ******/
    FL_I2C_Master_EnableRX(I2Cx); // ??????
    FL_I2C_Master_SetRespond(I2Cx, FL_I2C_MASTER_RESPOND_NACK); // ???NACK
    
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_RXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter < I2C_TIMEOUT)
    {
        data = FL_I2C_Master_ReadRXBuff(I2Cx); // ????
        FL_I2C_Master_ClearFlag_RXComplete(I2Cx);
    }

    /****** ???? ******/
    FL_I2C_Master_EnableI2CStop(I2Cx); // STOP
    return data;
}

