#ifndef __EPSC_H__
#define __EPSC_H__

#include "fm33fk5xx_fl.h"

#define LCD_WIDTH         240            // ÆÁÄ»¿í¶ÈÏñËØ£¬×¢Òâ£º0~239
#define LCD_HIGH          320            // ÆÁÄ»¸ß¶ÈÏñËØ£¬×¢Òâ£º0~319
#define LCD_DIR           0              // Ä¬ÈÏÏÔÊ¾·½Ïò£¬0-ÕýÊúÆÁ£¬3-µ¹ÊúÆÁ£¬5-ÕýºáÆÁ, 6-µ¹ºáÆÁ
#define USE_LCM_DIR  	  0   	//¶¨ÒåÒº¾§ÆÁË³Ê±ÕëÐý×ª·½Ïò 	0-0¶ÈÐý×ª£¬1-180¶ÈÐý×ª£¬2-270¶ÈÐý×ª£¬3-90¶ÈÐý×ª
#define USE_TP_TYPE   	CTP 	//¶¨Òå´¥ÃþÀàÐÍ  CTP = µçÈÝÄ£Ê½ , RTP = µç×èÄ£Ê½

#define CTP 0X80		//µçÈÝÄ£Ê½
#define RTP 0X00		//µç×èÄ£Ê½	 

//颜色
#define      WHITE               0xFFFF    // °×É«
#define      BLACK               0x0000    // ºÚÉ« 
#define      GREY                0xF7DE    // »ÒÉ« 
#define      RED                 0xF800    // ºì 
#define      MAGENTA             0xF81F    // ÑóºìÉ« 
#define      GRED                0xFFE0    // ÉîºìÉ«
#define      GREEN               0x07E0    // ÂÌ 
#define      CYAN                0x7FFF    // ÇàÉ« 
#define      YELLOW              0xFFE0    // »ÆÉ« 
#define      LIGHTGREEN          0X841F    // Ç³ÂÌÉ« 
#define      BLUE                0x001F    // À¶ 
#define      GBLUE               0x07FF    // Ç³À¶ 1
#define      LIGHTBLUE           0X7D7C    // Ç³À¶ 2
#define      BLUE2               0x051F    // Ç³À¶ 3
#define      GRAYBLUE            0X5458    // »ÒÀ¶ 
#define      DARKBLUE            0X01CF    // ÉîÀ¶

#define      LGRAY               0XC618    // Ç³»ÒÉ«,´°Ìå±³¾°É«
#define      LGRAYBLUE           0XA651    // Ç³»ÒÀ¶É«(ÖÐ¼ä²ãÑÕÉ«)
#define      LBBLUE              0X2B12    // Ç³×ØÀ¶É«(Ñ¡ÔñÌõÄ¿µÄ·´É«)

//LCD地址结构体
typedef struct
{
    uint16_t LCD_REG;
    uint16_t LCD_RAM;
} LCD_TypeDef;
#define LCD_BASE        ((uint32_t)(0x6C000000 | 0x000007E))
#define LCD             ((LCD_TypeDef *) LCD_BASE)

//LCD重要参数集
typedef struct
{
		uint8_t  FlagInit;									//初始化完成标志
    uint16_t    width;                  //LCD 宽度
    uint16_t    height;                 //LCD 高度
    uint32_t    id;                         //LCD ID
    uint8_t     dir;                        //横屏还是竖屏控制：0，竖屏；1，横屏。
    uint16_t    wramcmd;                //开始写gram指令
    uint16_t  setxcmd;              //设置x坐标指令
    uint16_t  setycmd;              //设置y坐标指令
} lcd_struct;

extern void LCD_Config(void);
extern void LCD_Clear(uint16_t color);
void LCD_DisplayDir(uint8_t scanDir);
void LCD_Fill(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color);
void LCD_Color_Fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t *color);
void LCD_DisplayOn(void);
void LCD_DrawPoint(uint16_t x, uint16_t y, uint16_t color);

#endif
