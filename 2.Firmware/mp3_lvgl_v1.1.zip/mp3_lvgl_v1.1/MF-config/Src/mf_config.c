/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : mf_config.c
  * @brief          : MCU FUNCTION CONFIG
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 FMSH.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by FMSH under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "mf_config.h"
#include "lvgl.h"
#include "audio.h"
/* Private function prototypes -----------------------------------------------*/

/**
  * @brief  The application entry point.
  * @retval int
  */
/**
  * @brief  LCD Initialization function
  * @param  void
  * @retval None
  */
void MF_LCD_Init(void)
{

    FL_GPIO_InitTypeDef    GPIO_InitStruct;
    EPSC_NORSRAM_InitTypeDef    EPSC_NORSRAMInitStructure;
    EPSC_NORSRAM_RWTimingTypeDef  readWriteTiming;
    EPSC_NORSRAM_WTimingTypeDef     writeTiming;
    //D4_D10
    GPIO_InitStruct.pin           = FL_GPIO_PIN_9 | FL_GPIO_PIN_10 | FL_GPIO_PIN_11 | FL_GPIO_PIN_12 | FL_GPIO_PIN_13 | FL_GPIO_PIN_14 | FL_GPIO_PIN_15;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    //D0_D1
    GPIO_InitStruct.pin           = FL_GPIO_PIN_10 | FL_GPIO_PIN_11;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    //D2_D3
    GPIO_InitStruct.pin           = FL_GPIO_PIN_5 | FL_GPIO_PIN_6;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    //D11_D12
    GPIO_InitStruct.pin           = FL_GPIO_PIN_14 | FL_GPIO_PIN_15;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    //D13_D15
    GPIO_InitStruct.pin           = FL_GPIO_PIN_2 | FL_GPIO_PIN_3 | FL_GPIO_PIN_4;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOF, &GPIO_InitStruct);
		
		//测试灯
		GPIO_InitStruct.pin           = FL_GPIO_PIN_5;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X4;
    (void)FL_GPIO_Init(GPIOF, &GPIO_InitStruct);
		
    //A6_NOE
    GPIO_InitStruct.pin           = FL_GPIO_PIN_15 | FL_GPIO_PIN_9;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    //NE4
    GPIO_InitStruct.pin           = FL_GPIO_PIN_10;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    //NWE_RESET
    GPIO_InitStruct.pin           = FL_GPIO_PIN_10;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    //BL
    GPIO_InitStruct.pin           = FL_GPIO_PIN_7;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);
    FL_GPIO_SetOutputPin(GPIOE, FL_GPIO_PIN_7);

    //RESET
    GPIO_InitStruct.pin           = FL_GPIO_PIN_14;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON4;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOC, &GPIO_InitStruct);
    FL_GPIO_SetOutputPin(GPIOC, FL_GPIO_PIN_14);
    FL_DelayMs(100);
    FL_GPIO_ResetOutputPin(GPIOC, FL_GPIO_PIN_14);
    FL_DelayMs(500);
    FL_GPIO_SetOutputPin(GPIOC, FL_GPIO_PIN_14);
    FL_DelayMs(100);

    readWriteTiming.AddressSetupTime = 1;
    readWriteTiming.AddressHoldTime = 5;
    readWriteTiming.DataSetupTime = 0x04;
    readWriteTiming.BusTurnAroundDuration = FL_EPSC_NTR_BUS_TRUNAROUND_0CLK;
    readWriteTiming.CLKDivision = FL_EPSC_NTR_CLK_DIV2;
    readWriteTiming.DataLatency = FL_EPSC_NTR_DATA_LATENCY_2CLK;
    readWriteTiming.AccessMode = FL_EPSC_NTR_EXTMOD_MODE_A;                                                 //模式A


    writeTiming.AddressSetupTime = 0;
    writeTiming.AddressHoldTime = 5;
    writeTiming.DataSetupTime = 0x04;
    writeTiming.BusTurnAroundDuration = FL_EPSC_NWTR_BUS_TRUNAROUND_0CLK;
    writeTiming.AccessMode = FL_EPSC_NWTR_EXTMOD_MODE_A;                                                        //模式A

    EPSC_NORSRAMInitStructure.NSBank = FL_EPSC_BANK1_NORSRAM4;                                          //这里我们使用NE4
    EPSC_NORSRAMInitStructure.DataAddressMux = FL_DISABLE;                                                  //不复用数据地址
    EPSC_NORSRAMInitStructure.MemoryType = FL_EPSC_NCR_MEMORY_TYPE_SRAM;                        //SRAM
    EPSC_NORSRAMInitStructure.MemoryDataWidth = FL_EPSC_NCR_MEMORY_WIDTH_16B;               //存储器数据宽度为16bit
    EPSC_NORSRAMInitStructure.BurstAccessMode = FL_DISABLE;
    EPSC_NORSRAMInitStructure.WriteBurst = FL_DISABLE;

    EPSC_NORSRAMInitStructure.WaitSignal = FL_DISABLE;
    EPSC_NORSRAMInitStructure.AsynchronousWait = FL_DISABLE;
    EPSC_NORSRAMInitStructure.WaitSignalPolarity = FL_EPSC_NCR_POLARITY_LOW;
    EPSC_NORSRAMInitStructure.WaitSignalActive = FL_EPSC_NCR_ACTIVE_STATE_BEFORE;
    EPSC_NORSRAMInitStructure.WriteOperation = FL_ENABLE;                                                       //存储器写使能
    EPSC_NORSRAMInitStructure.ExtendedMode = FL_ENABLE;                                                         //读写使用不同的时序
    EPSC_NORSRAMInitStructure.ReadWriteTimingStruct = &readWriteTiming;                         //读写时序
    EPSC_NORSRAMInitStructure.WriteTimingStruct = &writeTiming;                                         //写时序

		FL_EPSC_NORSRAM_Init(EPSC, &EPSC_NORSRAMInitStructure);                                                 //初始化FSMC配置
}

void MF_I2C_Init(void)
{

    FL_GPIO_InitTypeDef    GPIO_InitStruct;

    FL_I2C_MasterMode_InitTypeDef    defaultInitStruct;
	
	   GPIO_InitStruct.pin = FL_GPIO_PIN_8;                                     /*??GPIO????*/
    GPIO_InitStruct.mode = FL_GPIO_MODE_DIGITAL;                                /*??GPIO?????*/
    GPIO_InitStruct.outputType = FL_GPIO_OUTPUT_OPENDRAIN;                       /*??GPIO?????*/
    GPIO_InitStruct.pull = FL_GPIO_PULLUP_ENABLE;                                /*??GPIO??????*/
    GPIO_InitStruct.remapPin = FL_GPIO_PINREMAP_FUNCTON3;                       /*??GPIO???????*/
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;                   /*??GPIO????*/
    GPIO_InitStruct.analogSwitch = FL_DISABLE;                                  /*??GPIO??????*/
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);                                /*GPIO???*/
	
    GPIO_InitStruct.pin = FL_GPIO_PIN_15;                                     /*??GPIO????*/
    GPIO_InitStruct.mode = FL_GPIO_MODE_DIGITAL;                                /*??GPIO?????*/
    GPIO_InitStruct.outputType = FL_GPIO_OUTPUT_OPENDRAIN;                       /*??GPIO?????*/
    GPIO_InitStruct.pull = FL_GPIO_PULLUP_ENABLE;                                /*??GPIO??????*/
    GPIO_InitStruct.remapPin = FL_GPIO_PINREMAP_FUNCTON3;                       /*??GPIO???????*/
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;                   /*??GPIO????*/
    GPIO_InitStruct.analogSwitch = FL_DISABLE;                                  /*??GPIO??????*/
    (void)FL_GPIO_Init(GPIOB, &GPIO_InitStruct); 
		
    defaultInitStruct.baudRate    = 100000U;
		
    FL_I2C_MasterMode_Init(I2C1, &defaultInitStruct);

}
void MF_GPIO_Init(void)
{

    FL_GPIO_InitTypeDef    GPIO_InitStruct;

		GPIO_InitStruct.pin           = FL_GPIO_PIN_8;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_INPUT;
		GPIO_InitStruct.remapPin   		= FL_DISABLE;
    GPIO_InitStruct.pull          = FL_DISABLE;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
	
		(void)FL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
void MF_SPI_Init(void)
{
	  FL_SPI_InitTypeDef    SPI_InitStruct = {0};
    FL_GPIO_InitTypeDef    GPIO_InitStruct;
    /* PB0: SSN  PB1: SCK  PB2: MISO  PB3:MOSI */
    GPIO_InitStruct.pin           = FL_GPIO_PIN_0 | FL_GPIO_PIN_1 | FL_GPIO_PIN_2 | FL_GPIO_PIN_3;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON3;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    SPI_InitStruct.softControl    = FL_ENABLE;                       //软件控制SSN使能
    SPI_InitStruct.mode           = FL_SPI_WORK_MODE_MASTER;         //主机模式
    SPI_InitStruct.baudRate       = FL_SPI_PCLK_DIV64;                //波特率：8M/4=2M
    SPI_InitStruct.bitOrder       = FL_SPI_BIT_ORDER_MSB_FIRST;      //先发送MSB
    SPI_InitStruct.dataWidth_l    = FL_SPI_DATAL_LENGTH0;
    SPI_InitStruct.dataWidth_h    = FL_SPI_DATAH_LENGTH0;            //数据长度：8bit
    SPI_InitStruct.clockPhase     = FL_SPI_PHASE_EDGE1;              //时钟相位
    SPI_InitStruct.clockPolarity  = FL_SPI_POLARITY_NORMAL;            //时钟极性
    SPI_InitStruct.transferMode   = FL_SPI_TRANSFER_MODE_FULL_DUPLEX;//全双工

    FL_SPI_Init(SPI0, &SPI_InitStruct);
}
void MF_Clock_Init(void)
{
    FL_CMU_SetSystemClock(FL_SYSTEM_CLOCK_PLL_RCHF_80M);
}
void GPTIM0_Init(void)
{
    FL_GPTIM_InitTypeDef    TimerBaseInitStruct;

    TimerBaseInitStruct.prescaler = 80 - 1;
    TimerBaseInitStruct.counterMode = FL_GPTIM_COUNTER_DIR_DOWN;
    TimerBaseInitStruct.autoReload = 1000 - 1;
    TimerBaseInitStruct.autoReloadState = FL_DISABLE;
    TimerBaseInitStruct.clockDivision = FL_GPTIM_CLK_DIVISION_DIV1;
    FL_GPTIM_Init(GPTIM0, &TimerBaseInitStruct);

    FL_GPTIM_ClearFlag_Update(GPTIM0);
    FL_GPTIM_EnableIT_Update(GPTIM0);

    NVIC_DisableIRQ(GPTIM0_IRQn);
    NVIC_SetPriority(GPTIM0_IRQn, 2);
    NVIC_EnableIRQ(GPTIM0_IRQn);

    FL_GPTIM_Enable(GPTIM0);
}

//lvgl的心跳
void GPTIM0_IRQHandler(void)
{
    if(FL_GPTIM_IsEnabledIT_Update(GPTIM0) && FL_GPTIM_IsActiveFlag_Update(GPTIM0))
    {
				lv_tick_inc(1);
        FL_GPTIM_ClearFlag_Update(GPTIM0);
    }
}

void GPTIM1_Init(void)
{
    FL_GPTIM_InitTypeDef    TimerBaseInitStruct;

    TimerBaseInitStruct.prescaler = 80 - 1;
    TimerBaseInitStruct.counterMode = FL_GPTIM_COUNTER_DIR_DOWN;
    TimerBaseInitStruct.autoReload = 300 - 1;
    TimerBaseInitStruct.autoReloadState = FL_DISABLE;
    TimerBaseInitStruct.clockDivision = FL_GPTIM_CLK_DIVISION_DIV1;
    FL_GPTIM_Init(GPTIM1, &TimerBaseInitStruct);

    FL_GPTIM_ClearFlag_Update(GPTIM1);
    FL_GPTIM_EnableIT_Update(GPTIM1);

    NVIC_DisableIRQ(GPTIM1_IRQn);
    NVIC_SetPriority(GPTIM1_IRQn, 3);
    NVIC_EnableIRQ(GPTIM1_IRQn);

    FL_GPTIM_Enable(GPTIM1);
}
void GPTIM1_IRQHandler(void)
{
    if(FL_GPTIM_IsEnabledIT_Update(GPTIM1) && FL_GPTIM_IsActiveFlag_Update(GPTIM1))
    {
				audio_player_task();
        FL_GPTIM_ClearFlag_Update(GPTIM1);
    }
}


//ds1302的驱动
void MF_OUTRTC_Init(void)
{
		FL_GPIO_InitTypeDef    GPIO_InitStruct;
	  GPIO_InitStruct.pin           = FL_GPIO_PIN_11 | FL_GPIO_PIN_13;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
		GPIO_InitStruct.remapPin   		= FL_DISABLE;
    GPIO_InitStruct.pull          = FL_DISABLE;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);
}

void MF_OUTRTC_Data_Out_Init(void)
{
		FL_GPIO_InitTypeDef    GPIO_InitStruct;
	  GPIO_InitStruct.pin           = FL_GPIO_PIN_12;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
		GPIO_InitStruct.remapPin   		= FL_DISABLE;
    GPIO_InitStruct.pull          = FL_DISABLE;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct);
}

void MF_OUTRTC_Data_In_Init(void)
{
    FL_GPIO_InitTypeDef    GPIO_InitStruct_in;

		GPIO_InitStruct_in.pin           = FL_GPIO_PIN_12;
    GPIO_InitStruct_in.mode          = FL_GPIO_MODE_INPUT;
		GPIO_InitStruct_in.remapPin   		= FL_DISABLE;
    GPIO_InitStruct_in.pull          = FL_GPIO_PULLUP_ENABLE;
    GPIO_InitStruct_in.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct_in.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
		GPIO_InitStruct_in.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
	
		(void)FL_GPIO_Init(GPIOE, &GPIO_InitStruct_in);
}

void MF_Audio_SPI_Init(void)
{
    FL_SPI_InitTypeDef    SPI_InitStruct = {0};
    FL_GPIO_InitTypeDef    GPIO_InitStruct;
    /*PA1: SCK  PA2: MISO  PA3:MOSI */
    GPIO_InitStruct.pin           = FL_GPIO_PIN_2 | FL_GPIO_PIN_3;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON2;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
    GPIO_InitStruct.pin           = FL_GPIO_PIN_1;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_DIGITAL;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.pull          = FL_GPIO_BOTH_DISABLE;
    GPIO_InitStruct.remapPin      = FL_GPIO_PINREMAP_FUNCTON3;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
    SPI_InitStruct.softControl    = FL_DISABLE;                       //软件控制SSN使能
    SPI_InitStruct.mode           = FL_SPI_WORK_MODE_MASTER;         //主机模式
    SPI_InitStruct.baudRate       = FL_SPI_PCLK_DIV64;                //波特率：8M/4=2M
    SPI_InitStruct.bitOrder       = FL_SPI_BIT_ORDER_MSB_FIRST;      //先发送MSB
    SPI_InitStruct.dataWidth_l    = FL_SPI_DATAL_LENGTH0;
    SPI_InitStruct.dataWidth_h    = FL_SPI_DATAH_LENGTH0;            //数据长度：8bit
    SPI_InitStruct.clockPhase     = FL_SPI_PHASE_EDGE1;              //时钟相位
    SPI_InitStruct.clockPolarity  = FL_SPI_POLARITY_NORMAL;            //时钟极性
    SPI_InitStruct.transferMode   = FL_SPI_TRANSFER_MODE_FULL_DUPLEX;//全双工

    FL_SPI_Init(SPI1, &SPI_InitStruct);
}

void MF_Audio_CS_Init(void)
{
    FL_SPI_InitTypeDef    SPI_InitStruct = {0};
    FL_GPIO_InitTypeDef    GPIO_InitStruct;
    /*PA4: XCS  PA5: XDCS  PA6: DREQ PA7: RST*/
    GPIO_InitStruct.pin           = FL_GPIO_PIN_4 | FL_GPIO_PIN_5 | FL_GPIO_PIN_7;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.outputType    = FL_GPIO_OUTPUT_PUSHPULL;
		GPIO_InitStruct.remapPin   		= FL_DISABLE;
    GPIO_InitStruct.pull          = FL_DISABLE;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
    (void)FL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
		GPIO_InitStruct.pin           = FL_GPIO_PIN_6;
    GPIO_InitStruct.mode          = FL_GPIO_MODE_INPUT;
		GPIO_InitStruct.remapPin   		= FL_DISABLE;
    GPIO_InitStruct.pull          = FL_DISABLE;
    GPIO_InitStruct.analogSwitch  = FL_DISABLE;
    GPIO_InitStruct.driveStrength = FL_GPIO_DRIVESTRENGTH_X3;
		(void)FL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void MF_Config_Init(void)
{
    MF_LCD_Init();
	  MF_I2C_Init();
		MF_SPI_Init();
		MF_Audio_SPI_Init();
		MF_Audio_CS_Init();
		MF_OUTRTC_Init();
		MF_GPIO_Init();
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */

    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN Assert_Failed */
    /* User can add his own implementation to report the file name and line number,
       tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    /* USER CODE END Assert_Failed */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT FMSH *****END OF FILE****/
