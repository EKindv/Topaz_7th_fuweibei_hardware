#ifndef __HOMEPAGE_H__
#define __HOMEPAGE_H__

#include "lvgl.h"
#include "stdlib.h"
// 图标数量
#define icon_count          4
// 图标之间的距离
#define icon_distance       140
// 小图标的尺寸
#define icon_size_small     96
// 大图标的尺寸
#define icon_size_big       96
// 圆角半径
#define CORNER_RADIUS   10  
//翻页阈值速度（大于此速度则触发连续翻页）
#define touch_state   10  

// 定义图标结构体，包含图标对象指针和x坐标
typedef struct
{
  lv_obj_t * obj;
  int32_t x;
}icon_typedef;

// 声明图标结构体数组
static icon_typedef icon[icon_count];
// 触摸状态标志
static bool touched=false;
// 屏幕宽度
static int32_t scr_w;
// 触摸偏移量x
static int32_t t_offset_x;

static lv_obj_t * music;
//基准坐标
static int16_t base_pos[icon_count];
//图标上下限 
static int32_t min_scroll = 0;
static int32_t max_scroll = (icon_count-1)*icon_distance;

// 按下事件回调函数声明
static void  pressing_cb(lv_event_t * e);
// 释放事件回调函数声明
static void  released_cb(lv_event_t * e);
// 设置x坐标回调函数声明
static void set_x_cb(void * var, int16_t v);
// 自定义动画创建函数声明
static void lv_myanim_creat(void * var,lv_anim_exec_xcb_t exec_cb,uint32_t time, uint32_t delay,lv_anim_path_cb_t path_cb,
                             int32_t start, int32_t end,lv_anim_ready_cb_t completed_cb);
//事件处理函数
static void my_event_cb(lv_obj_t * obj, lv_event_t event);
void switch_to_clock() ;
static int32_t find_nearest_center(); 

void switch_to_music_player();
void switch_to_reader() ;
void switch_to_recoder();
void switch_to_img_viewer();

static void update_icons_position(bool animate);
//ui创建函数
void scrollicon();
#endif
