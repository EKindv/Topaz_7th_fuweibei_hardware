#include "lvgl.h"
#include "clock.h"
#include "stdlib.h"
#include "ds1302.h"
#include "homepage.h"
#include "style.h"
#include "mooncake_handler.h"

#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320

static lv_obj_t * time_label;

static lv_point_t start_point;       // 记录触摸起始点

static uint8_t read_time[7];  // DS1302原始数据缓冲区

static void switch_handler(lv_obj_t * obj, lv_event_t event);
static void my_event_cb(lv_obj_t *obj, lv_event_t event);

void switch_to_homepage();

void clock_alarm(void)
{
	    // 如果已经存在，先删除旧页面
    if (clock_screen) {
        lv_obj_del(clock_screen);
        clock_screen = NULL;
    }	
		LV_FONT_DECLARE(font_clock_80);
				
	    /* 创建全屏容器 */
    clock_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(clock_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(clock_screen, &lv_style_transp_fit);
    lv_obj_set_event_cb(clock_screen, my_event_cb);
		
//	  // 启用容器的拖动手势
    lv_obj_set_drag(clock_screen, true);
    lv_obj_set_drag_dir(clock_screen, LV_DRAG_DIR_VER); // 只允许垂直拖动
    lv_obj_set_drag_throw(clock_screen, true); // 启用拖动后惯性
	
    /* 创建时间显示标签 */
    time_label = lv_label_create(clock_screen, NULL);
		lv_label_set_text(time_label, "00:00");
	
		/*创建分割装饰线*/
    lv_obj_t *line = lv_line_create(clock_screen, NULL);
		static lv_point_t line_points[] = {
    {10, 125},  // 起点坐标 (x, y)
    {230, 125}  // 终点坐标 (x, y)
		};

		// 应用样式
		lv_line_set_points(line, line_points, 2);    // 设置点数组和点数量
		lv_line_set_style(line, LV_LINE_STYLE_MAIN, &line_style);
		
    /* 设置大字体样式 */
    static lv_style_t time_style;
    lv_style_copy(&time_style, &lv_style_plain);
    time_style.text.font = &font_clock_80;
    time_style.text.color = LV_COLOR_MAKE(197, 199, 150);
    
    lv_label_set_style(time_label, LV_LABEL_STYLE_MAIN, &time_style);
    lv_obj_set_pos(time_label,10,60);
		
    /* 创建闹钟标签 */
    lv_obj_t *alarm_label = lv_label_create(clock_screen, NULL);
    lv_label_set_text(alarm_label, "alarm");
    lv_label_set_style(alarm_label, LV_LABEL_STYLE_MAIN, &style_font_primary);
    lv_obj_set_pos(alarm_label, 20, 150);
    
    /* 创建开关 */
    lv_obj_t *sw = lv_sw_create(clock_screen, NULL);
    lv_obj_set_pos(sw, 160, 150);
    
    // 设置开关尺寸
    lv_obj_set_size(sw, 60, 30); // 宽度60px，高度30px
    
    // 设置动画时间
    lv_sw_set_anim_time(sw, 300); // 300ms动画时间
    
    /* 设置开关样式 */
    // 背景样式
		/* 背景样式 - 滑槽 */
		static lv_style_t bg_style;
		lv_style_copy(&bg_style, &lv_style_plain);
		bg_style.body.radius = LV_RADIUS_CIRCLE;         // 圆形端点
		bg_style.body.main_color = LV_COLOR_MAKE(93,106,105);
		bg_style.body.grad_color = LV_COLOR_MAKE(93,106,105);
		bg_style.body.opa = LV_OPA_COVER;               // 完全不透明
		bg_style.body.padding.top = 0;                  // 上内边距
		bg_style.body.padding.bottom = 0;               // 下内边距
		bg_style.body.padding.left = 0;                 // 左内边距
		bg_style.body.padding.right =0;                // 右内边距
		bg_style.body.border.width = 0;                 // 无边框
		bg_style.body.shadow.width = 0;                 // 无阴影
		lv_sw_set_style(sw, LV_SW_STYLE_BG, &bg_style);

		/* 指示器样式 - 活动部分 */
		static lv_style_t indic_style;
		lv_style_copy(&indic_style, &lv_style_plain);
		indic_style.body.radius = LV_RADIUS_CIRCLE;      // 圆形端点
		indic_style.body.main_color = LV_COLOR_MAKE(150,170,199);
		indic_style.body.grad_color = LV_COLOR_MAKE(150,170,199);
		indic_style.body.opa = LV_OPA_COVER;             // 完全不透明
		indic_style.body.padding.top = 0;                // 无内边距
		indic_style.body.padding.bottom = 0;             
		indic_style.body.padding.left = 0;               
		indic_style.body.padding.right = 0;              
		indic_style.body.border.width = 0;               // 无边框
		indic_style.body.shadow.width = 0;               // 无阴影
		lv_sw_set_style(sw, LV_SW_STYLE_INDIC, &indic_style);
		
		/* 关闭状态旋钮样式 */
		static lv_style_t knob_off_style;
		lv_style_copy(&knob_off_style, &lv_style_plain);
		knob_off_style.body.radius = LV_RADIUS_CIRCLE;   // 圆形旋钮
		knob_off_style.body.main_color = LV_COLOR_MAKE(233,252,252);// 白色旋钮
		knob_off_style.body.grad_color = LV_COLOR_MAKE(233,252,252); // 无渐变
		knob_off_style.body.opa = LV_OPA_COVER;          // 完全不透明
		knob_off_style.body.padding.top = 1;             // 无内边距
		knob_off_style.body.padding.bottom = 1;          
		knob_off_style.body.padding.left = 0;            
		knob_off_style.body.padding.right = 0;           
		knob_off_style.body.border.width = 1;            // 边框宽度1px
		knob_off_style.body.border.color = LV_COLOR_MAKE(233,252,252);
		knob_off_style.body.border.opa = LV_OPA_COVER;   // 边框不透明
		knob_off_style.body.shadow.width = 6;            // 阴影宽度
		knob_off_style.body.shadow.color = LV_COLOR_MAKE(233,252,252);
		knob_off_style.body.shadow.type = LV_SHADOW_BOTTOM; // 底部阴影
		lv_sw_set_style(sw, LV_SW_STYLE_KNOB_OFF, &knob_off_style);
		
		/* 开启状态旋钮样式 */
		static lv_style_t knob_on_style;
		lv_style_copy(&knob_on_style, &knob_off_style);  // 继承关闭状态样式
		knob_on_style.body.main_color = LV_COLOR_MAKE(233,252,252);
		knob_on_style.body.grad_color = LV_COLOR_MAKE(233,252,252);
//		knob_on_style.body.border.color = LV_COLOR_MAKE(46,138,215); // 深蓝色边框
		knob_on_style.body.shadow.color = LV_COLOR_MAKE(46,138,215); // 更深的阴影
		lv_sw_set_style(sw, LV_SW_STYLE_KNOB_ON, &knob_on_style);
  
	   if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    /* 添加开关事件回调 */
    lv_obj_set_event_cb(sw, switch_handler);
		
}

void update_clock_from_rtc(void) {
    static uint8_t last_second = 0xFF;
    
    ds1032_read_time();
    ds1032_read_realTime();
    
    if(TimeData.second == last_second) return;
    last_second = TimeData.second;
    
    char time_buf[9];
    time_buf[0] = '0' + (TimeData.hour / 10);
    time_buf[1] = '0' + (TimeData.hour % 10);
    time_buf[2] = ':';
    time_buf[3] = '0' + (TimeData.minute / 10);
    time_buf[4] = '0' + (TimeData.minute % 10);
    
    lv_label_set_text(time_label, time_buf);
}

static void switch_handler(lv_obj_t * obj, lv_event_t event) {
    if(event == LV_EVENT_VALUE_CHANGED) {
        // 获取开关当前状态
        bool state = lv_sw_get_state(obj);
        
        // 根据状态执行不同操作
        if(state) {
            // 开关开启时的处理
//            LV_LOG_USER("Alarm activated");
            // 示例: 启动闹钟
            // start_alarm();
        } else {
            // 开关关闭时的处理
//            LV_LOG_USER("Alarm deactivated");
            // 示例: 关闭闹钟
            // stop_alarm();
        }
    }
}

static void my_event_cb(lv_obj_t *obj, lv_event_t event)
{    
    switch(event) {
        case LV_EVENT_PRESSED: {
            // 记录触摸起始点
            lv_indev_t *indev = lv_indev_get_act();
            if (indev) {
                lv_indev_get_point(indev, &start_point);
            }
            break;
        }
        
        case LV_EVENT_DRAG_END: {
            // 获取当前触摸点
            lv_point_t end_point;
            lv_indev_t *indev = lv_indev_get_act();
            if (!indev) break;
            lv_indev_get_point(indev, &end_point);
            
            // 计算垂直滑动距离
            int16_t dy = end_point.y - start_point.y;
            
            // 如果向上滑动超过阈值
            if (dy < -200) {
							switch_to_homepage();
            }
            break;
        }
    }
}

void switch_to_homepage() {
    // 隐藏主页
		if (clock_screen) {
        lv_obj_set_hidden(clock_screen, true);
		}
    if (home_screen) {
        lv_obj_set_hidden(home_screen, false);
    }
    else{
        scrollicon();
    }	
		current_screen = home_screen;
}
