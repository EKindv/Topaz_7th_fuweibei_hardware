#ifndef __CLOCK_H__
#define __CLOCK_H__

#include "lvgl.h"
#include "stdlib.h"


void clock_alarm(void);
void update_clock_from_rtc(void);
	

#endif
