#include "lvgl.h"
#include "stdlib.h"
#include "reader.h"
#include "homepage.h"
#include "audio.h"
#include "style.h"
#include "img.h"
#include "mooncake_handler.h"
#include <string.h>

#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320
#define TOTAL_IMAGES 3  // 固定为3张图片

// 图片浏览相关变量
uint8_t current_image_index = 0; // 当前图片索引 (0-2)
lv_obj_t *img_view = NULL;      // 图片显示对象
lv_obj_t *status_label_img = NULL;  // 状态标签

// 加载并显示当前图片
void load_current_image() {
	
		lv_img_set_src(img_view, NULL);
		lv_refr_now(NULL); // 立即刷新，确保释放
    // 动态生成图片路径 (节省内存)
    char img_path[20];
    snprintf(img_path, sizeof(img_path), "0:/IMG/%d.bin", current_image_index + 1);
    
    // 设置图片源
    lv_img_set_src(img_view, img_path);
    // 更新状态标签
    if(status_label_img) {
        lv_label_set_text_fmt(status_label_img, "%d/%d", current_image_index + 1, TOTAL_IMAGES);
    }
}

// 图片浏览器事件处理
static void img_event_handler(lv_obj_t * obj, lv_event_t event) {
    static lv_point_t start_point;
    
    switch(event) {
        case LV_EVENT_PRESSED:{
            lv_indev_t *indev = lv_indev_get_act();
            if(indev) {
                lv_indev_get_point(indev, &start_point);
            }
            break;
					}
        case LV_EVENT_PRESSING: {
            lv_indev_t *indev = lv_indev_get_act();
            if(!indev) return;
            
            lv_point_t point;
            lv_indev_get_point(indev, &point);
            
            int16_t diff_x = point.x - start_point.x;
            int16_t diff_y = point.y - start_point.y;
            
            // 水平滑动检测（左右切换图片）
            if(abs(diff_x) > 20 && abs(diff_x) > abs(diff_y)) {
                if(diff_x > 0) {
                    // 向右滑动 - 上一张
                    current_image_index = (current_image_index == 0) ? (TOTAL_IMAGES - 1) : (current_image_index - 1);
                } else {
                    // 向左滑动 - 下一张
                    current_image_index = (current_image_index + 1) % TOTAL_IMAGES;
                }
                load_current_image();
                start_point = point; // 重置起点
            }
            // 垂直滑动检测（上滑返回）
            else if(diff_y < -30 && abs(diff_y) > abs(diff_x)) {
                // 返回主页
                lv_obj_del(img_viewer_screen);
                img_viewer_screen = NULL;
                
                // 显示主页
                if(home_screen) {
                    lv_obj_set_hidden(home_screen, false);
                    current_screen = home_screen;
                } else {
                    scrollicon();  // 如果主页不存在则创建
                }
            }
            break;
        }
    }
}

// 创建图片浏览器界面
void create_image_viewer(void) {
    // 创建全屏容器
    img_viewer_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(img_viewer_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(img_viewer_screen, &lv_style_transp_fit);
    current_screen = img_viewer_screen;
		lv_obj_set_event_cb(img_viewer_screen, img_event_handler);
		lv_obj_set_click(img_viewer_screen, true);    
    // 创建图片显示对象
    img_view = lv_img_create(img_viewer_screen, NULL);
    lv_obj_set_size(img_view, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_align(img_view, NULL, LV_ALIGN_CENTER, 0, 0);
    lv_img_set_auto_size(img_view, false);
    
    // 加载第一张图片
    current_image_index = 0;
    load_current_image();
    
    // 添加状态提示
    status_label_img = lv_label_create(img_viewer_screen, NULL);
    lv_label_set_text_fmt(status_label_img, "%d/%d", current_image_index + 1, TOTAL_IMAGES);
    lv_obj_align(status_label_img, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, -10);

}