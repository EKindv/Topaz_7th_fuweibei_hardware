#ifndef __MOONCAKE_HANDLER_H__
#define __MOONCAKE_HANDLER_H__

#include "lvgl.h"
#include "stdlib.h"

extern lv_obj_t *current_screen;
extern lv_obj_t *home_screen;
extern lv_obj_t *clock_screen;
extern lv_obj_t *music_player_screen;
extern lv_obj_t *mic_screen;
extern lv_obj_t *img_viewer_screen;





#endif
