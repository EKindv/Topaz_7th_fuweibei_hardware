//V1.0 泛用型任务调度软件生命周期调度管理
#include "lvgl.h"
#include "homepage.h"
#include "stdlib.h"
#include "mooncake_handler.h"
#include "audio.h"
#include "clock.h"
#include "reader.h"
#include "mic.h"
#include "style.h"
#include "img.h"

lv_obj_t *current_screen = NULL;							//当前页面
lv_obj_t *home_screen = NULL;									//主页
lv_obj_t *clock_screen = NULL;								//时钟与闹钟主页
lv_obj_t *music_player_screen = NULL;					//音乐播放器
lv_obj_t *mic_screen = NULL;									//录音
lv_obj_t *img_viewer_screen = NULL;						//图片浏览器

