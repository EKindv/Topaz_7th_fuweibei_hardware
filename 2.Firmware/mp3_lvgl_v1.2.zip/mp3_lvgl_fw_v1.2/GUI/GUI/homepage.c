#include "lvgl.h"
#include "homepage.h"
#include "stdlib.h"
#include "EPSC.h"
#include "audio.h"
#include "clock.h"
#include "reader.h"
#include "mic.h"
#include "style.h"
#include "img.h"
#include "mooncake_handler.h"

uint8_t dir = 0;
uint8_t current_mid_index = icon_count/2;
lv_obj_t *top_label;
// 辅助函数：将点坐标转换为屏幕坐标
static void convert_point_to_screen(lv_obj_t *obj, lv_point_t *point)
{
    // 递归计算对象在屏幕上的绝对位置
    lv_obj_t *parent = obj;
    while(parent) {
        point->x += lv_obj_get_x(parent);
        point->y += lv_obj_get_y(parent);
        parent = lv_obj_get_parent(parent);
    }
}

// 滚动图标功能函数
void scrollicon()
{
    int32_t i;
		LV_FONT_DECLARE(mic_28);
    
    // 创建全屏容器
    home_screen  = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(home_screen , 240, 320);
    lv_cont_set_style(home_screen , LV_CONT_STYLE_MAIN, &lv_style_plain_color);
    lv_obj_set_style(home_screen , &lv_style_transp);
		current_screen = home_screen;
	
    // 为整个屏幕添加触摸事件
    lv_obj_set_event_cb(home_screen , my_event_cb);

		
    // 创建图标容器
    lv_obj_t *icon_container = lv_cont_create(home_screen , NULL);
    lv_obj_set_size(icon_container, 240, icon_size_big);
		lv_obj_set_pos(icon_container,0, (240 - icon_size_small) / 2);
    lv_cont_set_fit(icon_container, LV_FIT_NONE);
    lv_cont_set_layout(icon_container, LV_LAYOUT_OFF);
    lv_page_set_sb_mode(icon_container, LV_SB_MODE_OFF);
		lv_obj_set_style(icon_container, &lv_style_transp);
		lv_obj_set_click(icon_container, true);  // 启用点击		
		lv_obj_set_event_cb(icon_container, my_event_cb);
		
		// 顶部装饰栏（灰色长条）
    lv_obj_t *top_bar = lv_cont_create(home_screen, NULL);
    lv_obj_set_pos(top_bar, 0, 0); // 位于屏幕底部
    lv_obj_set_size(top_bar, 240, 20);
    
    // 样式（灰色背景）
    static lv_style_t bar_style;
    lv_style_copy(&bar_style, &lv_style_plain);
    bar_style.body.main_color = LV_COLOR_MAKE(137, 137, 137);
    bar_style.body.grad_color = LV_COLOR_MAKE(137, 137, 137);
    bar_style.body.border.width = 0;
    bar_style.body.radius = 0;
		lv_obj_set_style(top_bar, &bar_style);
		
		top_label = lv_label_create(top_bar, NULL);	
		lv_obj_set_pos(top_label,70, 2);
		lv_label_set_text_fmt(top_label,"wav_recoder");
		lv_obj_set_style(top_label, &style_font_secondary_dark);		
		
    for (i = 0; i < icon_count; i++)
    {
				static lv_style_t icon_label_style_row;
				lv_style_copy(&icon_label_style_row, &style_font_primary_dark);
				icon_label_style_row.text.font = &mic_28; // 使用合适的字体
			
        icon[i].obj = lv_obj_create(icon_container, NULL);
			
        lv_obj_set_style(icon[i].obj, &style_btn);
        
        // 初始化为小尺寸
        lv_obj_set_size(icon[i].obj, icon_size_small, icon_size_small);
        
        // 设置位置
        icon[i].x = (i - current_mid_index) * icon_distance + (240 - icon_size_small) / 2;
        lv_obj_set_pos(icon[i].obj, icon[i].x, 0);
				lv_obj_set_user_data(icon[i].obj, (void*)(intptr_t)i);
				lv_obj_set_event_cb(icon[i].obj, my_event_cb);        
        // 创建标签
        lv_obj_t *label = lv_label_create(icon[i].obj, NULL);

				if(i==1){
				  lv_label_set_text_fmt(label,LV_SYMBOL_AUDIO);
					lv_obj_set_style(label, &style_font_primary_dark);
				}
				else if(i==0)
				{ lv_label_set_text_fmt(label,LV_SYMBOL_FILE);
					lv_obj_set_style(label, &style_font_primary_dark);}
        else if(i==2)
				{
					lv_label_set_text_fmt(label,LV_SYMBOL_RECORD);
					lv_obj_set_style(label, &icon_label_style_row);
					
				}
				else if(i==3)
				{
					lv_label_set_text_fmt(label,LV_SYMBOL_IMAGE);
					lv_obj_set_style(label, &style_font_primary_dark);
					
				}
				
        lv_obj_align(label, NULL, LV_ALIGN_CENTER, 0, 0);
    }
}

// 按下事件回调函数
static void pressing_cb(lv_event_t *e)
{
    static lv_point_t click_point1;
    lv_indev_t *indev = lv_indev_get_act();
    
    if (!touched) {
        lv_indev_get_point(indev, &click_point1);
        touched = true;
    }
}

// 释放事件回调函数
static void released_cb(lv_event_t *e)
{
    // 恢复所有图标的正常样式
    for (int i = 0; i < icon_count; i++) {
        lv_obj_set_style(icon[i].obj, &style_btn);
    }
    
    // 根据滑动方向更新中间索引
    if (dir == 0) { // 左滑（实际显示右移）
        current_mid_index = (current_mid_index - 1 + icon_count) % icon_count;
    } else if (dir == 1) { // 右滑（实际显示左移）
        current_mid_index = (current_mid_index + 1) % icon_count;
    }
		if(current_mid_index==1){
			lv_obj_set_pos(top_label,70, 2);
			lv_label_set_text_fmt(top_label,"music_player");
		}
		else if(current_mid_index==0)
		{ 
			lv_obj_set_pos(top_label,78, 2);
			lv_label_set_text_fmt(top_label,"txt_viewer");
		}
		else if(current_mid_index==2)
		{
			lv_obj_set_pos(top_label,73, 2);
			lv_label_set_text_fmt(top_label,"wav_recoder");		
		}
		else if(current_mid_index==3)
		{
			lv_obj_set_pos(top_label,78, 2);
			lv_label_set_text_fmt(top_label,"img_viewer");
		}
    // 更新所有图标位置和大小
    update_icons_position(true);
}

// 更新图标位置和大小（带动画）
static void update_icons_position(bool animate)
{
    int32_t center_x = 120;
    static uint8_t prev_mid_index = icon_count/2;
				
    for (int i = 0; i < icon_count; i++) {
        // 计算相对于中间位置的偏移量
        int offset = (i - current_mid_index) * icon_distance;
        
        // 计算目标位置
        int32_t target_x;
        if (i == current_mid_index) {
            target_x = center_x - icon_size_big / 2;
        } else {
            target_x = center_x + offset - icon_size_small / 2;
        }
        
        // 跳过屏幕外的图标（避免穿越效果）
        if (abs(offset) > icon_distance * 2) {
            lv_obj_set_hidden(icon[i].obj, true);
            continue;
        } else {
            lv_obj_set_hidden(icon[i].obj, false);
        }
        
        if (animate) {
            // 创建动画
            lv_anim_t a;
            lv_anim_init(&a);
            lv_anim_set_exec_cb(&a,icon[i].obj ,(lv_anim_exec_xcb_t)lv_obj_set_x);
            lv_anim_set_values(&a, lv_obj_get_x(icon[i].obj), target_x);
            lv_anim_set_time(&a, 400, 0);
            lv_anim_set_path_cb(&a, lv_anim_path_ease_out);
            lv_anim_create(&a);
        } else {
            lv_obj_set_x(icon[i].obj, target_x);
        }
        
        // 更新图标大小（根据与中心的距离）
        int32_t distance = abs(offset);
        int32_t size;
        if (distance > icon_distance) {
            size = icon_size_small;
        } else {
            // 线性插值计算大小
            size = icon_size_small + (icon_size_big - icon_size_small) * 
                   (1.0 - (float)distance / icon_distance);
        }
        
        lv_obj_set_size(icon[i].obj, size, size);
        
        // 更新位置记录
        icon[i].x = target_x;
    }
}

static void my_event_cb(lv_obj_t *obj, lv_event_t event)
{    
    static int16_t start_x = 0;
		static int16_t start_y = 0;
    static int16_t last_x = 0;
	  static bool is_pressing_icon = false;
    static lv_obj_t *pressed_icon = NULL;
    lv_indev_t *indev = lv_indev_get_act();
    lv_point_t point;
    
    switch(event) {
        case LV_EVENT_PRESSED:
            lv_indev_get_point(indev, &point);
            start_x = point.x;
						start_y	= point.y;
            last_x = point.x;
						touched = false;
            is_pressing_icon = false;
				if((point.x<130+icon_size_big/2)&&(point.x>110-icon_size_big/2))
				{
					if((point.y> (220 - icon_size_small) / 2)&&(point.y< (260 + icon_size_small) / 2))
					{
							is_pressing_icon = true;
							pressed_icon = icon[current_mid_index].obj;
						 lv_obj_set_style(pressed_icon, &style_btn_pressed);
					}
				}

						break;
									
        case LV_EVENT_PRESSING:
            lv_indev_get_point(indev, &point);
            {
                // 当检测到滑动时，取消按下状态
                if (is_pressing_icon && abs(point.x - start_x) > 5) {
                    lv_obj_set_style(pressed_icon, &style_btn);
                    is_pressing_icon = false;
                    pressed_icon = NULL;
                }			
                int16_t diff = point.x - last_x;
                last_x = point.x;
								if(point.y - start_y>50)
								{
									switch_to_clock();
								}
                // 更新所有图标位置
                for (int i = 0; i < icon_count; i++) {
                    int32_t new_x = icon[i].x + diff;
                    
                    // 限制图标在屏幕范围内
                    if (new_x < -icon_size_big || new_x > 240 + icon_size_big) {
                        continue;
                    }
                    
                    lv_obj_set_x(icon[i].obj, new_x);
                    icon[i].x = new_x;
                }
                
                // 确定滑动方向
                dir = (point.x > start_x) ? 0 : 1;
								if(point.x == start_x)
								{dir = 3;}
            }
            break;
            
        case LV_EVENT_RELEASED:
            // 恢复被按下的图标样式
            if (is_pressing_icon && pressed_icon) {
                lv_obj_set_style(pressed_icon, &style_btn);
            }
						if(is_pressing_icon)
								{dir = 3;}
            released_cb(&event);
            break;
            
        case LV_EVENT_CLICKED:
            if (is_pressing_icon && pressed_icon) {
                int index = (int)(intptr_t)lv_obj_get_user_data(pressed_icon);
                if (index == current_mid_index) {
                    if(index == 0)
										{
											switch_to_reader();
										}
										else if(index == 1)
										{
											switch_to_music_player();
										}
										else if(index == 2)
										{
											switch_to_recoder();
										}
										else if(index == 3)
										{
											switch_to_img_viewer();
										}
                    // open_app(index);
                }
                // 重置状态
                is_pressing_icon = false;
                pressed_icon = NULL;
            }
            break;
    }
}
void switch_to_music_player() {
    // 隐藏主页
    if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    
//    // 显示或创建音乐播放器
//    if (music_player_screen) {
////        lv_obj_set_hidden(music_player_screen, false);
//    } else {
        create_music_player();
//    }
    
    current_screen = music_player_screen;
}

void switch_to_clock() {
    // 隐藏主页
    if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    // 显示或创建时钟页面
    if (clock_screen) {
        lv_obj_del(clock_screen);
				clock_alarm();  // 创建时钟页面
		}
		else{
		clock_alarm();
		}

			    
    current_screen = clock_screen;
}
void switch_to_reader() {
    // 隐藏主界面
    if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    
    // 创建或显示文件浏览器
    if (reader_screen) {
        lv_obj_set_hidden(reader_screen, false);
    } else {
        txt_reader_init();  // 初始化阅读器
    }
    
    current_screen = reader_screen;
}

void switch_to_recoder() {
    // 隐藏主界面
    if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    create_recorder_ui(); 
    current_screen = mic_screen;
}

void switch_to_img_viewer() {
    // 隐藏主界面
    if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
    create_image_viewer(); 
    current_screen = img_viewer_screen;
}
