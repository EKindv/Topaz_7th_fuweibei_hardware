#include "lvgl.h"
#include "stdlib.h"
#include "reader.h"
#include "homepage.h"
#include "audio.h"
#include "style.h"
#include "mooncake_handler.h"
#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320


static FIL txt_file;               // 文本文件对象
static lv_obj_t *text_label;       // 用于显示文本的标签

static char file_buffer[800];      // 更大的文件内容缓冲区
static uint32_t file_position = 0; // 当前文件位置
static uint32_t file_size = 0;     // 文件总大小
static int current_page_index = 0; // 当前页码
static int total_pages = 0;        // 总页数
static uint32_t *page_offsets = NULL; // 每页起始位置数组
static int max_page_lines = 0;     // 每页最大行数

#define MAX_FILE_COUNT 3          // 最大文件数量

// 存储文件完整路径//这里复用了音乐播放器里的内存,不然占用特别大

static int file_count = 0;         // 当前文件数量
static int current_file_index = 0; // 当前打开的文件索引

// 计算每页最大行数
void calculate_max_lines() {
    // 获取标签的实际高度
    lv_coord_t label_height = 280; // 增大文本显示区域
    
    // 获取字体信息
    const lv_font_t *font = lv_label_get_style(text_label, LV_LABEL_STYLE_MAIN)->text.font;
    
    // 计算行高（字体高度 + 行间距）
    const lv_style_t *style = lv_label_get_style(text_label, LV_LABEL_STYLE_MAIN);
    lv_coord_t line_height = font->line_height + style->text.line_space;
    
    // 计算每页最大行数
    max_page_lines = (label_height) / line_height;
    
    // 确保至少有1行
    if (max_page_lines < 1) max_page_lines = 1;
}

// 计算文件总行数
int calculate_total_lines() {
    FRESULT res;
    UINT bytes_read;
    char buffer[256];
    int lines = 0;
    uint32_t pos = 0;
    
    // 重置文件位置
    f_lseek(&txt_file, 0);
    
    while (1) {
        res = f_read(&txt_file, buffer, sizeof(buffer), &bytes_read);
        if (res != FR_OK || bytes_read == 0) break;
        
        // 计算缓冲区中的行数
        for (int i = 0; i < bytes_read; i++) {
            if (buffer[i] == '\n') lines++;
        }
        
        pos += bytes_read;
        if (pos >= file_size) break;
    }
    
    // 如果文件不以换行结束，则加上最后一行
    if (bytes_read > 0 && buffer[bytes_read-1] != '\n') lines++;
    
    return lines;
}

// 智能分页 - 计算每页起始位置
void calculate_page_offsets() {
    // 释放旧的页偏移数组
    if (page_offsets) {
        free(page_offsets);
        page_offsets = NULL;
    }
    
    // 计算总行数和每页最大行数
    int total_lines = calculate_total_lines();
    calculate_max_lines();
    
    // 计算总页数
    total_pages = (total_lines + max_page_lines - 1) / max_page_lines;
    if (total_pages < 1) total_pages = 1;
    
    // 分配页偏移数组
    page_offsets = malloc((total_pages + 1) * sizeof(uint32_t));
    if (!page_offsets) {
        total_pages = 1;
        page_offsets = malloc(2 * sizeof(uint32_t));
        if (!page_offsets) return;
    }
    
    // 初始化页偏移
    page_offsets[0] = 0;
    page_offsets[total_pages] = file_size;  // 结束位置
    
    // 如果只有一页，直接返回
    if (total_pages == 1) return;
    
    // 计算每页起始位置
    FRESULT res;
    UINT bytes_read;
    char buffer[256];
    int current_line = 0;
    int current_page = 1;
    uint32_t pos = 0;
    
    f_lseek(&txt_file, 0);
    
    while (current_page < total_pages) {
        res = f_read(&txt_file, buffer, sizeof(buffer), &bytes_read);
        if (res != FR_OK || bytes_read == 0) break;
        
        for (int i = 0; i < bytes_read; i++) {
            if (buffer[i] == '\n') {
                current_line++;
                
                // 当达到页面行数时设置分页点
                if (current_line % max_page_lines == 0) {
                    page_offsets[current_page] = pos + i + 1;
                    current_page++;
                    
                    if (current_page >= total_pages) break;
                }
            }
        }
        
        pos += bytes_read;
        if (pos >= file_size) break;
    }
}

// 加载指定页的内容
void load_page(int page_index) {
    if (page_index < 0 || page_index >= total_pages) return;
    
    FRESULT res;
    UINT bytes_read;
    uint32_t start_pos = page_offsets[page_index];
    uint32_t end_pos = page_offsets[page_index + 1];
    uint32_t page_size = end_pos - start_pos;
    
    // 确保页面大小不超过缓冲区
    if (page_size > sizeof(file_buffer) - 1) {
        page_size = sizeof(file_buffer) - 1;
        end_pos = start_pos + page_size;
    }
    
    // 定位并读取页面内容
    f_lseek(&txt_file, start_pos);
    res = f_read(&txt_file, file_buffer, page_size, &bytes_read);
    
    if (res == FR_OK && bytes_read > 0) {
        // 确保字符串以空字符结尾
        file_buffer[bytes_read] = '\0';
        
        // 设置标签文本
        lv_label_set_text(text_label, file_buffer);
        
        current_page_index = page_index;
    } else {
        lv_label_set_text(text_label, "读取错误");
    }
}

// 初始化文件列表（从SD卡读取）
void init_file_list(const char* path) {
    FRESULT res;
    FILINFO fno;
    DIR dira;
    file_count = 0; // 重置计数器
    
    // 打开目录
    res = f_opendir(&dira, path);
    if (res != FR_OK) {
        return;
    }

    // 读取目录项
    while (file_count < MAX_FILE_COUNT) {
        res = f_readdir(&dira, &fno);
        if (res != FR_OK || fno.fname[0] == 0) break;
        
        // 跳过目录和隐藏文件
        if (fno.fname[0] == '.' || (fno.fattrib & AM_DIR)) continue;
        
        // 检查是否为文本文件
        char *ext = strrchr(fno.fname, '.');
        if (ext && (
            strcasecmp(ext, ".txt") == 0 || 
            strcasecmp(ext, ".c") == 0 ||
            strcasecmp(ext, ".h") == 0 ||
            strcasecmp(ext, ".cpp") == 0 ||
            strcasecmp(ext, ".md") == 0)) {
            
            // 构建完整路径
            snprintf(fileList[file_count], sizeof(fileList[0]), "%s/%s", path, fno.fname);
            file_count++;
        }
    }
    
    f_closedir(&dira);
}

// 读取并显示文件内容
void load_file_content(const char *filename) {
    FRESULT res;
    
    // 关闭之前打开的文件
    if (txt_file.fs != NULL) {
        f_close(&txt_file);
    }
    
    // 尝试打开文件
    res = f_open(&txt_file, filename, FA_READ);
    if (res != FR_OK) {
        lv_label_set_text(text_label, "打开错误");
        return;
    }
    
    // 获取文件大小
    file_size = f_size(&txt_file);
    
    // 计算分页信息
    calculate_page_offsets();
    
    // 加载第一页
    load_page(0);
}

// 切换到上一个文件
void prev_file() {
    if (file_count == 0) return;
    
    current_file_index = (current_file_index - 1 + file_count) % file_count;
    
    // 关闭当前文件
    if (txt_file.fs != NULL) {
        f_close(&txt_file);
    }
    
    // 释放页偏移数组
    if (page_offsets) {
        free(page_offsets);
        page_offsets = NULL;
    }
    
    // 加载新文件
    load_file_content(fileList[current_file_index]);
    
    // 更新标题
    const char *filename = strrchr(fileList[current_file_index], '/');
    if (filename == NULL) filename = fileList[current_file_index];
    else filename++;
    
    lv_label_set_text(reader_title, filename);
}

// 切换到下一个文件
void next_file() {
    if (file_count == 0) return;
    
    current_file_index = (current_file_index + 1) % file_count;
    
    // 关闭当前文件
    if (txt_file.fs != NULL) {
        f_close(&txt_file);
    }
    
    // 释放页偏移数组
    if (page_offsets) {
        free(page_offsets);
        page_offsets = NULL;
    }
    
    // 加载新文件
    load_file_content(fileList[current_file_index]);
    
    // 更新标题
    const char *filename = strrchr(fileList[current_file_index], '/');
    if (filename == NULL) filename = fileList[current_file_index];
    else filename++;
    
    lv_label_set_text(reader_title, filename);
}

// 上一页功能
void prev_page() {
    if (current_page_index > 0) {
        load_page(current_page_index - 1);
    }
}

// 下一页功能
void next_page() {
    if (current_page_index < total_pages - 1) {
        load_page(current_page_index + 1);
    }
}

// 阅读器页面手势事件处理
static void reader_event_handler(lv_obj_t * obj, lv_event_t event) {
    static lv_point_t start_point;
    static bool is_pressing = false;
    
    switch(event) {
        case LV_EVENT_PRESSED: {
            lv_indev_t *indev = lv_indev_get_act();
            if(indev) {
                lv_indev_get_point(indev, &start_point);
                is_pressing = true;
            }
            break;
        }
            
        case LV_EVENT_PRESSING: {
            if(!is_pressing) break;
            
            lv_indev_t *indev = lv_indev_get_act();
            if(!indev) return;
            
            lv_point_t point;
            lv_indev_get_point(indev, &point);
            
            int16_t diff_x = point.x - start_point.x;
            int16_t diff_y = point.y - start_point.y;
            
            // 水平滑动检测（左右翻页）
            if(abs(diff_x) > 30 && abs(diff_x) > abs(diff_y)) {
                if(diff_x > 0) {
                    // 向右滑动 - 上一页
                    prev_page();
                } else {
                    // 向左滑动 - 下一页
                    next_page();
                }
                start_point = point; // 重置起点
            }
            // 垂直滑动检测（上下切换文件）
            else if(abs(diff_y) > 100 && abs(diff_y) > abs(diff_x)) {
                if(diff_y > 0) {
                    // 向下滑动 - 下一个文件
                    next_file();
                } else {
                    // 向上滑动 - 上一个文件
                    prev_file();
                }
                start_point = point; // 重置起点
            }
            break;
        }
            
        case LV_EVENT_RELEASED:
            is_pressing = false;
            break;
            
        case LV_EVENT_PRESS_LOST:
            is_pressing = false;
            break;
    }
}

// 阅读器页面
void create_reader_page() {
    // 创建全屏透明容器
    reader_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(reader_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(reader_screen, &lv_style_transp_fit);
 
    lv_obj_set_event_cb(reader_screen, reader_event_handler);
    
    // 左上角返回按钮
    lv_obj_t *back_btn = lv_btn_create(reader_screen, NULL);
    lv_obj_set_pos(back_btn, 10, 10);
    lv_obj_set_size(back_btn, 40, 30);
		lv_obj_set_style(back_btn, &style_btn);
	
    lv_obj_t *back_label = lv_label_create(back_btn, NULL);
    lv_label_set_text(back_label, LV_SYMBOL_LEFT);
    lv_obj_align(back_label, NULL, LV_ALIGN_CENTER, 0, 0);
		lv_obj_set_style(back_label, &style_font_secondary);
		lv_btn_set_style(back_btn, LV_BTN_STYLE_REL, &style_btn);
    lv_btn_set_style(back_btn, LV_BTN_STYLE_PR, &style_btn_pressed);
	
    lv_obj_set_event_cb(back_btn, reader_back_action);    
    
    // 标题（文件名）
    reader_title = lv_label_create(reader_screen, NULL);
    lv_obj_set_pos(reader_title, 60, 15);

    lv_label_set_style(reader_title, LV_LABEL_STYLE_MAIN, &style_font_secondary);
		//装饰线
    lv_obj_t *line = lv_line_create(reader_screen, NULL);
		static lv_point_t line_points[] = {
    {10, 45},  // 起点坐标 (x, y)
    {230, 45}  // 终点坐标 (x, y)
		};
				// 应用样式
		lv_line_set_points(line, line_points, 2);    // 设置点数组和点数量
		lv_line_set_style(line, LV_LINE_STYLE_MAIN, &line_style);
		
    // 创建文本容器 
    text_cont  = lv_cont_create(reader_screen, NULL);
    lv_obj_set_pos(text_cont , 10, 50);
    lv_obj_set_size(text_cont , 220, 240); // 增大文本显示区域
    lv_obj_set_style(text_cont, &lv_style_transp_fit);
		lv_obj_set_event_cb(text_cont, reader_event_handler);
   // 创建文本标签
    text_label = lv_label_create(text_cont , NULL);
    lv_obj_set_size(text_label, 210, 230);
    lv_obj_align(text_label, NULL, LV_ALIGN_IN_TOP_LEFT, 5, 5);
    
    lv_label_set_style(text_label, LV_LABEL_STYLE_MAIN, &style_font_secondary);

    lv_label_set_long_mode(text_label, LV_LABEL_LONG_BREAK);
    lv_obj_set_width(text_label, 210);

}

// 初始化TXT阅读器
void txt_reader_init() {
    // 初始化文件列表
    init_file_list("0:/TXT");
    
    if (file_count == 0) {
        // 没有文件，显示提示
        create_reader_page();
        lv_label_set_text(text_label, "error");
        return;
    }
    
    // 创建阅读器页面
    create_reader_page();
    
    // 加载第一个文件
    current_file_index = 0;
    load_file_content(fileList[current_file_index]);
    
    // 设置标题
    const char *filename = strrchr(fileList[current_file_index], '/');
    if (filename == NULL) filename = fileList[current_file_index];
    else filename++;
    
    lv_label_set_text(reader_title, filename);
}

static void reader_back_action(lv_obj_t *btn, lv_event_t event) {
    if(event == LV_EVENT_CLICKED) {
        // 关闭文件
        if (txt_file.fs != NULL) {
            f_close(&txt_file);
        }
        
        // 释放页偏移数组
        if (page_offsets) {
            free(page_offsets);
            page_offsets = NULL;
        }
        
        // 删除阅读器页面
        if(reader_screen) {
            lv_obj_del(reader_screen);
            reader_screen = NULL;
        }
        
        // 显示主界面
        if (home_screen) {
            lv_obj_set_hidden(home_screen, false);
            current_screen = home_screen;
        } else {
            // 创建主页
            scrollicon();
        }
    }
}

int is_file_open(FIL *fp) {
    return (fp->fs != NULL);
}