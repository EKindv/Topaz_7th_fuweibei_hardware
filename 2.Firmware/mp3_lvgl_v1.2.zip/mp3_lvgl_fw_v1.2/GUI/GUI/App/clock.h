#ifndef __CLOCK_H__
#define __CLOCK_H__

#include "lvgl.h"
#include "stdlib.h"
#include "ff.h"

static lv_obj_t *alarm_label_f;
static lv_obj_t *alarm_label_b;
static lv_coord_t alarm_label_f_orig_y = 150;
static lv_coord_t alarm_label_b_orig_y = 150;

extern uint8_t alarm_time[4];

void clock_alarm(void);
void update_clock_from_rtc(void);
static void alarm_timeset_cb(lv_obj_t *obj, lv_event_t event);
void trigger_alarm_action(void);

#endif
