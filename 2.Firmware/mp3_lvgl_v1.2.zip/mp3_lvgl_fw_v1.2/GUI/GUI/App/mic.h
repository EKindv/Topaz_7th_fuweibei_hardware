#ifndef __MIC_H__
#define __MIC_H__
#include "lvgl.h"

static uint32_t last_time = 0;
		
// 录音状态
static uint8_t rec_sta = 0;      // 录音状态 [7]:0-无录音;1-有录音; [0]:0-录音中;1-暂停
static uint32_t rec_sec = 0;     // 录音时间(秒)
static uint32_t sectorsize = 0;  // 录音数据扇区计数
static uint8_t recagc = 4;       // 录音增益(默认4)

static uint8_t is_recording = 0; //录音状态标志位

void create_recorder_ui();
static void recoder_back_action(lv_obj_t *btn, lv_event_t event);
void recoder_new_pathname(char *pname);
void recoder_show_time(uint32_t tsec);
static void recorder_btn_handler(lv_obj_t * obj, lv_event_t event);
void recorder_process_data();
void recorder_update();
void update_recording_state(bool is_recording);
void record_data_cb(lv_task_t  * timer);
void audio_capture_handler(void);

	
#endif
