#include "lvgl.h"
#include "clock.h"
#include "stdlib.h"
#include "ds1302.h"
#include "homepage.h"
#include "style.h"
#include "mooncake_handler.h"
#include "stdio.h"
#include "vs1053.h"

#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320

uint8_t alarm_time[4] = {0,8,0,0};
uint8_t alarm_switch_state = 0; 
static lv_point_t hour_start_point;
static lv_point_t min_start_point;

static lv_obj_t * time_label;

static lv_point_t start_point;       // 记录触摸起始点

static uint8_t read_time[7];  // DS1302原始数据缓冲区

static void switch_handler(lv_obj_t * obj, lv_event_t event);
static void my_event_cb(lv_obj_t *obj, lv_event_t event);

void switch_to_homepage();

// 添加时间调整函数
static void adjust_alarm_time(lv_obj_t *label, bool is_hour, int direction) {
    char buf[3];
    int value = atoi(lv_label_get_text(label));
    
    if (is_hour) {
        // 小时调整 (0-23)
        value += direction; 
        if (value < 0) value = 23;
        else if (value > 23) value = 0;
        
        // 直接更新全局变量
        alarm_time[0] = value / 10;
        alarm_time[1] = value % 10;
    } else {
        // 分钟调整 (0-55, 步进5)
        value += (direction * 5);
        if (value < 0) value = 55;
        else if (value > 55) value = 0;
        
        // 直接更新全局变量
        alarm_time[2] = value / 10;
        alarm_time[3] = value % 10;
    }
    
    snprintf(buf, sizeof(buf), "%02d", value);
    lv_label_set_text(label, buf);
}

void clock_alarm(void)
{
	    // 如果已经存在，先删除旧页面
    if (clock_screen) {
        lv_obj_del(clock_screen);
        clock_screen = NULL;
    }	
		LV_FONT_DECLARE(font_clock_80);
		current_screen = clock_screen;
	    /* 创建全屏容器 */
    clock_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(clock_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(clock_screen, &lv_style_transp_fit);
    lv_obj_set_event_cb(clock_screen, my_event_cb);
		
	  // 启用容器的拖动手势
    lv_obj_set_drag(clock_screen, true);
    lv_obj_set_drag_dir(clock_screen, LV_DRAG_DIR_VER); // 只允许垂直拖动
    lv_obj_set_drag_throw(clock_screen, true); // 启用拖动后惯性
	
    /* 创建时间显示标签 */
    time_label = lv_label_create(clock_screen, NULL);
		lv_label_set_text(time_label, "00:00");
		
		/*创建分割装饰线*/
    lv_obj_t *line = lv_line_create(clock_screen, NULL);
		static lv_point_t line_points[] = {
    {10, 125},  // 起点坐标 (x, y)
    {230, 125}  // 终点坐标 (x, y)
		};

		// 应用样式
		lv_line_set_points(line, line_points, 2);    // 设置点数组和点数量
		lv_line_set_style(line, LV_LINE_STYLE_MAIN, &line_style);
		
    /* 设置大字体样式 */
    static lv_style_t time_style;
    lv_style_copy(&time_style, &lv_style_plain);
    time_style.text.font = &font_clock_80;
    time_style.text.color = LV_COLOR_MAKE(197, 199, 150);
    
    lv_label_set_style(time_label, LV_LABEL_STYLE_MAIN, &time_style);
    lv_obj_set_pos(time_label,10,60);
		
    /* 创建闹钟标签 */
    alarm_label_f = lv_label_create(clock_screen, NULL);
    char hour_buf[3];
    snprintf(hour_buf, sizeof(hour_buf), "%02d", alarm_time[0]*10 + alarm_time[1]);
    lv_label_set_text(alarm_label_f, hour_buf);
    lv_label_set_style(alarm_label_f, LV_LABEL_STYLE_MAIN, &style_font_primary);
    lv_obj_set_pos(alarm_label_f, 20, 150);
		
		lv_obj_t *alarm_label_m = lv_label_create(clock_screen, NULL);
    lv_label_set_text(alarm_label_m, ":");
    lv_label_set_style(alarm_label_m, LV_LABEL_STYLE_MAIN, &style_font_primary);
    lv_obj_set_pos(alarm_label_m, 53, 147);

    alarm_label_b = lv_label_create(clock_screen, NULL);
    char min_buf[3];
    snprintf(min_buf, sizeof(min_buf), "%02d", alarm_time[2]*10 + alarm_time[3]);
    lv_label_set_text(alarm_label_b, min_buf);
    lv_label_set_style(alarm_label_b, LV_LABEL_STYLE_MAIN, &style_font_primary);
    lv_obj_set_pos(alarm_label_b, 60, 150);
		
    // 设置点击事件回调
    lv_obj_set_event_cb(alarm_label_f, alarm_timeset_cb);
    lv_obj_set_event_cb(alarm_label_b, alarm_timeset_cb);
    
    // 确保标签可点击
    lv_obj_set_click(alarm_label_f, true);
    lv_obj_set_click(alarm_label_b, true);
		
    /* 创建开关 */
    lv_obj_t *sw = lv_sw_create(clock_screen, NULL);
    lv_obj_set_pos(sw, 160, 150);
    
    // 设置开关尺寸
    lv_obj_set_size(sw, 60, 30); // 宽度60px，高度30px
    
    // 设置动画时间
    lv_sw_set_anim_time(sw, 300); // 300ms动画时间
    
    /* 设置开关样式 */
    // 背景样式
		/* 背景样式 - 滑槽 */
		static lv_style_t bg_style;
		lv_style_copy(&bg_style, &lv_style_plain);
		bg_style.body.radius = LV_RADIUS_CIRCLE;         // 圆形端点
		bg_style.body.main_color = LV_COLOR_MAKE(93,106,105);
		bg_style.body.grad_color = LV_COLOR_MAKE(93,106,105);
		bg_style.body.opa = LV_OPA_COVER;               // 完全不透明
		bg_style.body.padding.top = 0;                  // 上内边距
		bg_style.body.padding.bottom = 0;               // 下内边距
		bg_style.body.padding.left = 0;                 // 左内边距
		bg_style.body.padding.right =0;                // 右内边距
		bg_style.body.border.width = 0;                 // 无边框
		bg_style.body.shadow.width = 0;                 // 无阴影
		lv_sw_set_style(sw, LV_SW_STYLE_BG, &bg_style);

		/* 指示器样式 - 活动部分 */
		static lv_style_t indic_style;
		lv_style_copy(&indic_style, &lv_style_plain);
		indic_style.body.radius = LV_RADIUS_CIRCLE;      // 圆形端点
		indic_style.body.main_color = LV_COLOR_MAKE(150,170,199);
		indic_style.body.grad_color = LV_COLOR_MAKE(150,170,199);
		indic_style.body.opa = LV_OPA_COVER;             // 完全不透明
		indic_style.body.padding.top = 0;                // 无内边距
		indic_style.body.padding.bottom = 0;             
		indic_style.body.padding.left = 0;               
		indic_style.body.padding.right = 0;              
		indic_style.body.border.width = 0;               // 无边框
		indic_style.body.shadow.width = 0;               // 无阴影
		lv_sw_set_style(sw, LV_SW_STYLE_INDIC, &indic_style);
		
		/* 关闭状态旋钮样式 */
		static lv_style_t knob_off_style;
		lv_style_copy(&knob_off_style, &lv_style_plain);
		knob_off_style.body.radius = LV_RADIUS_CIRCLE;   // 圆形旋钮
		knob_off_style.body.main_color = LV_COLOR_MAKE(233,252,252);// 白色旋钮
		knob_off_style.body.grad_color = LV_COLOR_MAKE(233,252,252); // 无渐变
		knob_off_style.body.opa = LV_OPA_COVER;          // 完全不透明
		knob_off_style.body.padding.top = 1;             // 无内边距
		knob_off_style.body.padding.bottom = 1;          
		knob_off_style.body.padding.left = 0;            
		knob_off_style.body.padding.right = 0;           
		knob_off_style.body.border.width = 1;            // 边框宽度1px
		knob_off_style.body.border.color = LV_COLOR_MAKE(233,252,252);
		knob_off_style.body.border.opa = LV_OPA_COVER;   // 边框不透明
		knob_off_style.body.shadow.width = 6;            // 阴影宽度
		knob_off_style.body.shadow.color = LV_COLOR_MAKE(233,252,252);
		knob_off_style.body.shadow.type = LV_SHADOW_BOTTOM; // 底部阴影
		lv_sw_set_style(sw, LV_SW_STYLE_KNOB_OFF, &knob_off_style);
		
		/* 开启状态旋钮样式 */
		static lv_style_t knob_on_style;
		lv_style_copy(&knob_on_style, &knob_off_style);  // 继承关闭状态样式
		knob_on_style.body.main_color = LV_COLOR_MAKE(233,252,252);
		knob_on_style.body.grad_color = LV_COLOR_MAKE(233,252,252);
//		knob_on_style.body.border.color = LV_COLOR_MAKE(46,138,215); // 深蓝色边框
		knob_on_style.body.shadow.color = LV_COLOR_MAKE(46,138,215); // 更深的阴影
		lv_sw_set_style(sw, LV_SW_STYLE_KNOB_ON, &knob_on_style);
		
    if(alarm_switch_state) {
        lv_sw_on(sw, LV_ANIM_OFF); // 开启状态
    } else {
        lv_sw_off(sw, LV_ANIM_OFF); // 关闭状态
    }
		
	   if (home_screen) {
        lv_obj_set_hidden(home_screen, true);
    }
		
    /* 添加开关事件回调 */
    lv_obj_set_event_cb(sw, switch_handler);
		
}

void update_clock_from_rtc(void) {
    static uint8_t last_second = 0xFF;
    static bool alarm_triggered = false;  // 防止重复触发
    
    ds1032_read_time();
    ds1032_read_realTime();
    
    if(TimeData.second == last_second) return;
    last_second = TimeData.second;
    
    char time_buf[9];
    snprintf(time_buf, sizeof(time_buf), "%02d:%02d", TimeData.hour, TimeData.minute);
    lv_label_set_text(time_label, time_buf);
    
    // 改进的闹钟检查逻辑
    if(alarm_switch_state && !alarm_triggered)
    {
        // 转换为整数比较
        uint8_t current_hour = TimeData.hour;
        uint8_t current_minute = TimeData.minute;
        
        uint8_t alarm_hour = alarm_time[0] * 10 + alarm_time[1];
        uint8_t alarm_minute = alarm_time[2] * 10 + alarm_time[3];
        
        if(current_hour == alarm_hour && current_minute == alarm_minute)
        {
						FL_GPIO_ResetOutputPin(GPIOB, FL_GPIO_PIN_7);
            VS_Sine_Test();
            alarm_triggered = false;  // 防止同一分钟内重复触发
						
        }
    }
    else if(TimeData.minute != (alarm_time[2] * 10 + alarm_time[3]))
    {
        // 分钟变化后重置触发标志
//				FL_GPIO_SetOutputPin(GPIOB, FL_GPIO_PIN_7);
        alarm_triggered = false;
    }
}

static void switch_handler(lv_obj_t * obj, lv_event_t event) {
    if(event == LV_EVENT_VALUE_CHANGED) {
        // 保存开关状态到全局变量
        alarm_switch_state = lv_sw_get_state(obj);
        
        // 根据状态执行不同操作
        if(alarm_switch_state) {
            // 开关开启时的处理
            // start_alarm();
        } else { 
						FL_GPIO_SetOutputPin(GPIOB, FL_GPIO_PIN_7);
            // 开关关闭时的处理
            // stop_alarm();
        }
    }
}

static void my_event_cb(lv_obj_t *obj, lv_event_t event)
{    
    switch(event) {
        case LV_EVENT_PRESSED: {
            // 记录触摸起始点
            lv_indev_t *indev = lv_indev_get_act();
            if (indev) {
                lv_indev_get_point(indev, &start_point);
            }
            break;
        }
        case LV_EVENT_DRAG_END: {
            // 获取当前触摸点
            lv_point_t end_point;
            lv_indev_t *indev = lv_indev_get_act();
            if (!indev) break;
            lv_indev_get_point(indev, &end_point);
            
            // 计算垂直滑动距离
            int16_t dy = end_point.y - start_point.y;
            
						    // 如果向上滑动距离小于阈值（200像素）
						if (dy < 0 && abs(dy) < 100) {
								// 创建复位动画
								lv_anim_t a;
								lv_anim_init(&a);
								lv_anim_set_exec_cb(&a,clock_screen, (lv_anim_exec_xcb_t)lv_obj_set_y);
								lv_anim_set_values(&a, lv_obj_get_y(clock_screen), 0); // 复位到Y=0位置
								lv_anim_set_time(&a, 300,0); // 300ms动画时间
								lv_anim_set_ready_cb(&a, NULL);
								lv_anim_create(&a);
						}
            // 如果向上滑动超过阈值
            else if (dy < -100) {
							switch_to_homepage();
            }
            break;
        }
    }
}


// 修改回调函数
static void alarm_timeset_cb(lv_obj_t *obj, lv_event_t event)
{    
    switch(event) {
        case LV_EVENT_CLICKED: {
            // 点击事件处理
            if (obj == alarm_label_f) {
                // 小时标签点击 - 加1
                adjust_alarm_time(obj, true, 1);
            } 
            else if (obj == alarm_label_b) {
                // 分钟标签点击 - 加5
                adjust_alarm_time(obj, false, 1);
            }
            break;
        }
    }
}
void switch_to_homepage() {
    // 隐藏主页
		if (clock_screen) {
        lv_obj_set_hidden(clock_screen, true);
		}
    if (home_screen) {
        lv_obj_set_hidden(home_screen, false);
    }
    else{
        scrollicon();
    }	
		current_screen = home_screen;
}