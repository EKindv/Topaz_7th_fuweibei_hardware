#include "lvgl.h"
#include "stdlib.h"
#include "ds1302.h"
#include "audio.h"
#include "homepage.h"
#include "vs1053.h"
#include "style.h"
#include "mooncake_handler.h"

#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320
DIR dira;            // 目录对象
FILINFO fno;        // 文件信息结构体

typedef enum {
    PLAYER_STOPPED,
    PLAYER_PLAYING,
    PLAYER_PAUSED
} PlayerState;


typedef enum {
    BTN_TYPE_PLAY,
    BTN_TYPE_PREV,
    BTN_TYPE_NEXT,
    BTN_TYPE_BACK,
    BTN_TYPE_MENU
} ButtonType;

typedef struct {
    PlayerState state;      // ????
    FIL currentFile;        // ???????
    uint32_t currentPos;    // ??????
	  uint32_t totalBytes;   // 文件总字节数
    uint32_t playedBytes;  // 已播放字节数
    uint8_t buffer[512];    // ?????
    uint32_t bufferPos;     // ???????
    uint32_t bufferSize;    // ?????????
    uint8_t needNewData;    // ???????
    uint8_t isFileOpened;   // ??????
} AudioPlayer;

char fileList[8][256];

uint8_t playing_channel = 0;

extern lv_obj_t *progress_bar; // 进度条对象（在UI中创建）
lv_obj_t *play_btn_label = NULL;

int totalFiles = 0;     // ????
int fileIndex = 0;      // ?????????
char currentSong[256] = ""; // ?????????
PlayerState playerState = PLAYER_PAUSED; // ?????
AudioPlayer audioPlayer; // ??????????
lv_obj_t *progress_bar = NULL;
lv_obj_t *song_name_label = NULL; // 用于显示歌曲名的标签

// 全局音量值（0-100）
static uint8_t current_volume = 75;
static void volume_bar_event_cb(lv_obj_t * obj, lv_event_t event);
static PlayerState pre_volume_adj_state = PLAYER_STOPPED;

const char* get_filename_from_path(const char* path) {
    const char *filename = strrchr(path, '/');
    return filename ? filename + 1 : path;
}

static void button_anim_event_cb(lv_obj_t * btn, lv_event_t event) {
    static bool styles_initialized = false;
    
    // 获取按钮类型
    ButtonType btn_type = (ButtonType)(intptr_t)lv_obj_get_user_data(btn);
    
    if (event == LV_EVENT_PRESSED) {
        // 按下时应用按下样式
        lv_btn_set_style(btn, LV_BTN_STYLE_PR, &style_btn_pressed);
        
        // 获取当前按钮位置和大小
        lv_coord_t x = lv_obj_get_x(btn);
        lv_coord_t y = lv_obj_get_y(btn);
        lv_coord_t width = lv_obj_get_width(btn);
        lv_coord_t height = lv_obj_get_height(btn);
        
        // 计算缩小后的位置和大小（向中心缩小）
        lv_coord_t new_width = width * 0.9;
        lv_coord_t new_height = height * 0.9;
        lv_coord_t new_x = x + (width - new_width) / 2;
        lv_coord_t new_y = y + (height - new_height) / 2;
        
        // 添加按下动画效果 - 向中心缩小
        lv_anim_t anim_size, anim_pos;
        
        // 大小动画
        lv_anim_init(&anim_size);
        lv_anim_set_values(&anim_size, width, new_width);
        lv_anim_set_time(&anim_size, 100,0);
        lv_anim_set_exec_cb(&anim_size, btn, (lv_anim_exec_xcb_t)lv_obj_set_width);
        lv_anim_create(&anim_size);
        
        lv_anim_init(&anim_size);
        lv_anim_set_values(&anim_size, height, new_height);
        lv_anim_set_time(&anim_size, 100,0);
        lv_anim_set_exec_cb(&anim_size, btn, (lv_anim_exec_xcb_t)lv_obj_set_height);
        lv_anim_create(&anim_size);
        
        // 位置动画
        lv_anim_init(&anim_pos);
        lv_anim_set_values(&anim_pos, x, new_x);
        lv_anim_set_time(&anim_pos, 100,0);
        lv_anim_set_exec_cb(&anim_pos, btn, (lv_anim_exec_xcb_t)lv_obj_set_x);
        lv_anim_create(&anim_pos);
        
        lv_anim_init(&anim_pos);
        lv_anim_set_values(&anim_pos, y, new_y);
        lv_anim_set_time(&anim_pos, 100,0);
        lv_anim_set_exec_cb(&anim_pos, btn, (lv_anim_exec_xcb_t)lv_obj_set_y);
        lv_anim_create(&anim_pos);
        
    } else if (event == LV_EVENT_RELEASED) {
        // 释放时应用释放样式
        lv_btn_set_style(btn, LV_BTN_STYLE_REL, &style_btn);
        
        // 获取当前按钮位置和大小
        lv_coord_t x = lv_obj_get_x(btn);
        lv_coord_t y = lv_obj_get_y(btn);
        lv_coord_t width = lv_obj_get_width(btn);
        lv_coord_t height = lv_obj_get_height(btn);
        
        // 原始位置和大小（从布局中获取）
        lv_coord_t orig_x = 0, orig_y = 0, orig_width = 0, orig_height = 0;
        
        // 根据按钮类型设置原始位置和大小
        switch (btn_type) {
            case BTN_TYPE_BACK:
                orig_x = 10; orig_y = 10; orig_width = 30; orig_height = 30;
                break;
            case BTN_TYPE_PREV:
                orig_x = 50; orig_y = 250; orig_width = 40; orig_height = 40;
                break;
            case BTN_TYPE_PLAY:
                orig_x = 100; orig_y = 250; orig_width = 40; orig_height = 40;
                break;
            case BTN_TYPE_NEXT:
                orig_x = 150; orig_y = 250; orig_width = 40; orig_height = 40;
                break;
            case BTN_TYPE_MENU:
                orig_x = 200; orig_y = 290; orig_width = 30; orig_height = 20;
                break;
        }
        
        // 添加释放动画效果 - 恢复原始大小和位置
        lv_anim_t anim_size, anim_pos;
        
        // 大小动画
        lv_anim_init(&anim_size);
        lv_anim_set_values(&anim_size, width, orig_width);
        lv_anim_set_time(&anim_size, 200,0);
        lv_anim_set_exec_cb(&anim_size, btn, (lv_anim_exec_xcb_t)lv_obj_set_width);
        lv_anim_create(&anim_size);
        
        lv_anim_init(&anim_size);
        lv_anim_set_values(&anim_size, height, orig_height);
        lv_anim_set_time(&anim_size, 200,0);
        lv_anim_set_exec_cb(&anim_size, btn, (lv_anim_exec_xcb_t)lv_obj_set_height);
        lv_anim_create(&anim_size);
        
        // 位置动画
        lv_anim_init(&anim_pos);
        lv_anim_set_values(&anim_pos, x, orig_x);
        lv_anim_set_time(&anim_pos, 200,0);
        lv_anim_set_exec_cb(&anim_pos, btn, (lv_anim_exec_xcb_t)lv_obj_set_x);
        lv_anim_create(&anim_pos);
        
        lv_anim_init(&anim_pos);
        lv_anim_set_values(&anim_pos, y, orig_y);
        lv_anim_set_time(&anim_pos, 200,0);
        lv_anim_set_exec_cb(&anim_pos, btn, (lv_anim_exec_xcb_t)lv_obj_set_y);
        lv_anim_create(&anim_pos);
            lv_obj_t *label = lv_obj_get_child(btn, NULL);        
        // 处理按钮功能
        switch (btn_type) {
            case BTN_TYPE_PLAY:
                // 切换播放/暂停状态
                if (playerState == PLAYER_PLAYING) {
                    playerState = PLAYER_PAUSED;
                    lv_label_set_text(label, LV_SYMBOL_PLAY);
                } else {
                    playerState = PLAYER_PLAYING;
                    lv_label_set_text(label, LV_SYMBOL_PAUSE);
                    
                    // 如果是第一次播放，初始化播放列表
                    if (totalFiles == 0) {
											init_playlist("0:/music"); // 修改为你的音乐目录
                    }
                }
                break;
                
            case BTN_TYPE_PREV:
                play_prev_song();	
                playerState = PLAYER_PLAYING;
                lv_label_set_text(play_btn_label, LV_SYMBOL_PAUSE);						
                break;
                
            case BTN_TYPE_NEXT:
                play_next_song();
								playerState = PLAYER_PLAYING;
                lv_label_set_text(play_btn_label, LV_SYMBOL_PAUSE);
                break;
                
            case BTN_TYPE_BACK:
                // 返回操作
                playerState = PLAYER_PAUSED;
								lv_label_set_text(play_btn_label, LV_SYMBOL_PLAY);
								FL_GPIO_SetOutputPin(GPIOB, FL_GPIO_PIN_7);
                // 关闭当前文件
                if (audioPlayer.isFileOpened) {
                    f_close(&audioPlayer.currentFile);
                    audioPlayer.isFileOpened = 0;
                }
								// 隐藏音乐播放器页面
								if (music_player_screen) {
										lv_obj_del(music_player_screen);
								}
								
								// 显示主页
								if (home_screen) {
										lv_obj_set_hidden(home_screen, false);
										current_screen = home_screen;
								} else {
										scrollicon();  // 如果主页不存在则创建
								}
                break;
                
            case BTN_TYPE_MENU:
							if(playing_channel == 0){
								FL_GPIO_ResetOutputPin(GPIOB, FL_GPIO_PIN_7);
								playing_channel = 1;
							}
							else if(playing_channel == 1){
								FL_GPIO_SetOutputPin(GPIOB, FL_GPIO_PIN_7);
								playing_channel = 0;
							}
								break;
        }
    }
}
	// 音量条触摸事件处理函数
static void volume_bar_event_cb(lv_obj_t * obj, lv_event_t event) {
    if (event == LV_EVENT_PRESSED) {
        // 保存当前播放状态
        pre_volume_adj_state = playerState;
        
        // 如果正在播放，则暂停播放
        if (playerState == PLAYER_PLAYING) {
            playerState = PLAYER_PAUSED;
            // 更新播放按钮图标
            if (play_btn_label) {
                lv_label_set_text(play_btn_label, LV_SYMBOL_PLAY);
            }
        }
    }
    else if (event == LV_EVENT_PRESSING) {
        // 获取触摸点位置
        lv_indev_t * indev = lv_indev_get_act();
        if (!indev) return;
        
        lv_point_t point;
        lv_indev_get_point(indev, &point);
        
        // 获取音量条的位置和大小
        lv_coord_t bar_x = lv_obj_get_x(obj);
        lv_coord_t bar_w = lv_obj_get_width(obj);
        
        // 计算触摸点在音量条上的相对位置 (0-100)
        int16_t rel_x = point.x - bar_x;
        if (rel_x < 0) rel_x = 0;
        if (rel_x > bar_w) rel_x = bar_w;
        
        // 计算新的音量值
        current_volume = (rel_x * 100) / bar_w;
        
        // 更新音量条显示
        lv_bar_set_value(obj, current_volume, LV_ANIM_OFF);
        
        // 设置实际音量（0-254）
        uint8_t vs_vol = (current_volume * 254 / 100); 
        VS_Set_Vol(vs_vol);
        
        // 更新音量图标
        const char* vol_icon = LV_SYMBOL_VOLUME_MID;
        if (current_volume == 0) {
            vol_icon = LV_SYMBOL_MUTE;
        } else if (current_volume < 33) {
            vol_icon = LV_SYMBOL_VOLUME_MID;
        } else if (current_volume > 66) {
            vol_icon = LV_SYMBOL_VOLUME_MAX;
        }
        
        // 查找音量图标对象并更新
        lv_obj_t * parent = lv_obj_get_parent(obj);
        for (lv_obj_t * child = lv_obj_get_child(parent, NULL); 
             child != NULL; 
             child = lv_obj_get_child(parent, child)) {
            
            if (lv_obj_get_user_data(child) == (void*)VOL_ICON_MARKER) {
                lv_label_set_text(child, vol_icon);
                break;
            }
        }
        pre_volume_adj_state = playerState; // 重置状态
    }
}


// 音乐播放器界面
void create_music_player(void) {

		init_playlist("0:/MUSIC/");    
    // 创建全屏透明容器
    music_player_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(music_player_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(music_player_screen, &lv_style_transp_fit);
    current_screen = music_player_screen;
    // 左上角返回按钮
    lv_obj_t *back_btn = lv_btn_create(music_player_screen, NULL);
    lv_obj_set_pos(back_btn, 10, 10);
    lv_obj_set_size(back_btn, 40, 30);
		lv_btn_set_style(back_btn, LV_BTN_STYLE_REL, &style_btn);
    lv_btn_set_style(back_btn, LV_BTN_STYLE_PR, &style_btn_pressed);
    lv_obj_set_user_data(back_btn, (void*)(intptr_t)BTN_TYPE_BACK); // 设置按钮类型
    // 返回箭头图标
    lv_obj_t *back_label = lv_label_create(back_btn, NULL);
    lv_label_set_text(back_label, LV_SYMBOL_LEFT);
    lv_obj_align(back_label, NULL, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_event_cb(back_btn, button_anim_event_cb); // 设置事件回调

    // 专辑封面区域（中心偏上） - 修改后的部分
		lv_obj_t *cover = lv_img_create(music_player_screen, NULL);
		lv_obj_set_pos(cover, 50, 50);
		lv_obj_set_size(cover, 140, 140);

		const char *cover_path = "0:/cover.bin";

		// 直接尝试加载图片
		lv_img_set_src(cover, cover_path);


    // 设置标签样式
    song_name_label = lv_label_create(music_player_screen, NULL);
    
    // 2. 设置位置和尺寸
    lv_obj_set_pos(song_name_label, 30, 200); // X位置30（居中于240宽度）
    lv_obj_set_size(song_name_label, 180, 25); // 宽度180，高度25	
    lv_obj_set_style(song_name_label, &style_font_secondary);
		lv_obj_set_width(song_name_label, 140);
    lv_label_set_text(song_name_label, "null");

    // 进度条
    progress_bar = lv_bar_create(music_player_screen, NULL);
    lv_obj_set_pos(progress_bar, 20, 220); // 位置(20,220)
    lv_obj_set_size(progress_bar, 200, 10); // 增加高度到15像素，更易见
    lv_bar_set_range(progress_bar, 0, 100);
    
    // 进度条背景样式 - 先设置背景
    static lv_style_t bar_bg_style;
    lv_style_copy(&bar_bg_style, &lv_style_plain);
    bar_bg_style.body.main_color = LV_COLOR_MAKE(50, 50, 50); // 深灰色背景
    bar_bg_style.body.grad_color = bar_bg_style.body.main_color;
    bar_bg_style.body.radius = 5;  // 圆角半径稍大
    bar_bg_style.body.border.width = 0;
    bar_bg_style.body.border.color = LV_COLOR_WHITE;
		bar_bg_style.body.padding.top = 0;      // 设置内边距为0
		bar_bg_style.body.padding.bottom = 0;
		bar_bg_style.body.padding.left = 0;
		bar_bg_style.body.padding.right = 0;
		bar_bg_style.body.padding.inner = 0; 	
    lv_bar_set_style(progress_bar, LV_BAR_STYLE_BG, &bar_bg_style);
    
    // 进度条前景样式 - 后设置前景
    static lv_style_t bar_style;
    lv_style_copy(&bar_style, &lv_style_plain);
    bar_style.body.main_color = LV_COLOR_MAKE(137, 137, 137); // 道奇蓝 - 更醒目的蓝色
    bar_style.body.grad_color = bar_style.body.main_color;
		bar_style.body.padding.top = 0;      // 设置内边距为0
		bar_style.body.padding.bottom = 0;
		bar_style.body.padding.left = 0;
		bar_style.body.padding.right = 0;
		bar_style.body.padding.inner = 0; 	
    bar_style.body.radius = 5;  // 与背景相同的圆角
    bar_style.body.border.width = 0;

    lv_bar_set_style(progress_bar, LV_BAR_STYLE_INDIC, &bar_style);
    
    // 设置初始值 - 确保在样式设置之后
    lv_bar_set_value(progress_bar,0, LV_ANIM_OFF);
    
    // 将进度条移到最上层 - 确保不被其他元素遮挡
    lv_obj_move_foreground(progress_bar);
		
		// 确保在界面创建时初始化播放列表并显示第一首歌曲名
    if (totalFiles == 0) {
        init_playlist("0:/music"); // 初始化播放列表
    }
    
    // 如果有歌曲，显示第一首歌曲名
    if (totalFiles > 0) {
        const char *name = get_filename_from_path(fileList[0]);
        lv_label_set_text(song_name_label, name);
        strcpy(currentSong, fileList[0]); // 设置当前歌曲
        fileIndex = 0; // 设置当前索引
    }
		
    // 控制按钮区域
    // 上一首按钮
    lv_obj_t *prev_btn = lv_btn_create(music_player_screen, NULL);
    lv_obj_set_pos(prev_btn, 50, 250); // 位置(50,250)
    lv_obj_set_size(prev_btn, 40, 40);
    lv_obj_set_user_data(prev_btn, (void*)(intptr_t)BTN_TYPE_PREV); // 设置按钮类型
    lv_obj_t *prev_label = lv_label_create(prev_btn, NULL);
    lv_label_set_text(prev_label, LV_SYMBOL_PREV);
    lv_obj_set_style(prev_btn, &style_btn);
    lv_obj_set_event_cb(prev_btn, button_anim_event_cb); // 设置事件回调
        
    // 播放按钮
    lv_obj_t *play_btn = lv_btn_create(music_player_screen, NULL);
    lv_obj_set_pos(play_btn, 100, 250);
    lv_obj_set_size(play_btn, 40, 40);
    lv_obj_set_user_data(play_btn, (void*)(intptr_t)BTN_TYPE_PLAY);
    lv_obj_set_style(play_btn, &style_btn);
    // 将标签保存到全局变量
    play_btn_label = lv_label_create(play_btn, NULL);
    // 根据当前状态设置初始图标
    lv_label_set_text(play_btn_label, (playerState == PLAYER_PLAYING) ? LV_SYMBOL_PAUSE : LV_SYMBOL_PLAY);
    lv_obj_align(play_btn_label, NULL, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_event_cb(play_btn, button_anim_event_cb); // 设置事件回调
        
    // 下一首按钮
    lv_obj_t *next_btn = lv_btn_create(music_player_screen, NULL);
    lv_obj_set_pos(next_btn, 150, 250); // 位置(150,250)
    lv_obj_set_size(next_btn, 40, 40);
    lv_obj_set_user_data(next_btn, (void*)(intptr_t)BTN_TYPE_NEXT); // 设置按钮类型
    lv_obj_t *next_label = lv_label_create(next_btn, NULL);
    lv_label_set_text(next_label, LV_SYMBOL_NEXT);
    lv_obj_set_style(next_btn, &style_btn);
    lv_obj_set_event_cb(next_btn, button_anim_event_cb); // 设置事件回调
        
    // 音量控制区域
    // 喇叭图标 - 添加标记以便查找
    lv_obj_t *vol_icon = lv_label_create(music_player_screen, NULL);
    lv_label_set_text(vol_icon, LV_SYMBOL_VOLUME_MID);
    lv_obj_set_pos(vol_icon, 20, 295); // 位置(20,295)
    lv_obj_set_user_data(vol_icon, (void*)VOL_ICON_MARKER); // 设置标记
    lv_obj_set_style(vol_icon, &style_btn);
    // 音量条
    lv_obj_t *volume_bar = lv_bar_create(music_player_screen, NULL);
    lv_obj_set_pos(volume_bar, 50, 300); // 位置(50,295)
    lv_obj_set_size(volume_bar, 140, 8); // 增加高度到12像素，更易见
    lv_bar_set_range(volume_bar, 0, 100);
    
    // 音量条背景样式 - 深灰色背景
    static lv_style_t vol_bg_style;
    lv_style_copy(&vol_bg_style, &lv_style_plain);
    vol_bg_style.body.main_color = LV_COLOR_MAKE(50, 50, 50); // 深灰色背景
    vol_bg_style.body.grad_color = vol_bg_style.body.main_color;
    vol_bg_style.body.radius = 4;  // 圆角半径
    vol_bg_style.body.border.width = 0;
		vol_bg_style.body.padding.top = 0;      // 设置内边距为0
		vol_bg_style.body.padding.bottom = 0;
		vol_bg_style.body.padding.left = 0;
		vol_bg_style.body.padding.right = 0;
		vol_bg_style.body.padding.inner = 0; 
    vol_bg_style.body.border.color = LV_COLOR_WHITE;
    lv_bar_set_style(volume_bar, LV_BAR_STYLE_BG, &vol_bg_style);
    
    // 音量条前景样式 - 绿色填充
    static lv_style_t vol_style;
    lv_style_copy(&vol_style, &lv_style_plain);
    vol_style.body.main_color = LV_COLOR_MAKE(137, 137, 137); // 亮绿色
		vol_style.body.padding.top = 0;      // 设置内边距为0
		vol_style.body.padding.bottom = 0;
		vol_style.body.padding.left = 0;
		vol_style.body.padding.right = 0;
		vol_style.body.padding.inner = 0; 		
    vol_style.body.grad_color = vol_style.body.main_color;
    vol_style.body.radius = 4;  // 与背景相同的圆角
    vol_style.body.border.width = 0;

    lv_bar_set_style(volume_bar, LV_BAR_STYLE_INDIC, &vol_style);
    
    // 设置初始值 - 确保在样式设置之后
    lv_bar_set_value(volume_bar, current_volume, LV_ANIM_OFF);
    
    // 将音量条移到最上层 - 确保不被其他元素遮挡
    lv_obj_move_foreground(volume_bar);
    
    // 添加触摸事件处理
    lv_obj_set_event_cb(volume_bar, volume_bar_event_cb);
    lv_obj_set_click(volume_bar, true); // 启用点击事件

		
    // 菜单按钮（歌曲选择）
    lv_obj_t *menu_btn = lv_btn_create(music_player_screen, NULL);
    lv_obj_set_pos(menu_btn, 200,292); // 位置(200,290)
    lv_obj_set_size(menu_btn, 30, 20);
    lv_obj_set_user_data(menu_btn, (void*)(intptr_t)BTN_TYPE_MENU); // 设置按钮类型
    lv_obj_t *menu_label = lv_label_create(menu_btn, NULL);
    lv_label_set_text(menu_label, "...");
    lv_obj_set_style(menu_btn, &style_btn);
    lv_obj_set_event_cb(menu_btn, button_anim_event_cb); // 设置事件回调
}


void init_playlist(const char* path) {
    FRESULT res;
    totalFiles = 0; // 重置计数器
    
    // 打开目录
    res = f_opendir(&dira, path);
    if (res != FR_OK) {
//        printf("无法打开目录: %d\n", res);
        return;
    }

    // 读取目录项
    while (1) {
        res = f_readdir(&dira, &fno);
        if (res != FR_OK || fno.fname[0] == 0) break;
        
        // 跳过目录和隐藏文件
        if (fno.fname[0] == '.' || (fno.fattrib & AM_DIR)) continue;
        
        // 检查是否为MP3文件（不区分大小写）
        char *ext = strrchr(fno.fname, '.');
        if (ext && (
            strcasecmp(ext, ".mp3") == 0 || 
            strcasecmp(ext, ".wav") == 0 ||
            strcasecmp(ext, ".flac") == 0)) {
            
            // 构建完整路径
            sprintf(fileList[totalFiles], "%s/%s", path, fno.fname);
            
            // 如果是当前播放的歌曲，记录索引
            if (strcmp(currentSong, fileList[totalFiles]) == 0) {
                fileIndex = totalFiles;
            }
            
            totalFiles++;
            
            // 防止超出数组限制
            if (totalFiles >= 10) break;
        }
    }
    
    f_closedir(&dira);
    
    // 如果没有当前歌曲，从第一首开始
    if (strlen(currentSong) == 0 && totalFiles > 0) {
        strcpy(currentSong, fileList[0]);
        fileIndex = 0;
    }
}

// 播放下一首歌曲
void play_next_song() {
    if (totalFiles == 0) return;
    
    // 关闭当前文件（如果有）
    if (audioPlayer.isFileOpened) {
        f_close(&audioPlayer.currentFile);
        audioPlayer.isFileOpened = 0;
    }
    
    // 移动到下一首（循环播放）
    fileIndex = (fileIndex + 1) % totalFiles;
    strcpy(currentSong, fileList[fileIndex]);
    
    // 重置播放器状态
    audioPlayer.needNewData = 1;
    audioPlayer.bufferPos = 0;
    audioPlayer.bufferSize = 0;
    audioPlayer.playedBytes = 0;
    audioPlayer.totalBytes = 0;
    
    // 重置进度条
    lv_bar_set_value(progress_bar, 0, LV_ANIM_OFF);
//    printf("下一首: %s\n", currentSong);
		if (song_name_label) {
        const char *name = get_filename_from_path(currentSong);
        lv_label_set_text(song_name_label, name);
				}
    playerState = PLAYER_PLAYING;

}

// 播放上一首歌曲
void play_prev_song() {
    if (totalFiles == 0) return;
    
    // 关闭当前文件（如果有）
    if (audioPlayer.isFileOpened) {
        f_close(&audioPlayer.currentFile);
        audioPlayer.isFileOpened = 0;
    }
    
    // 移动到上一首（循环播放）
    fileIndex = (fileIndex - 1 + totalFiles) % totalFiles;
    strcpy(currentSong, fileList[fileIndex]);
    
    // 重置播放器状态
    audioPlayer.needNewData = 1;
    audioPlayer.bufferPos = 0;
    audioPlayer.bufferSize = 0;
    audioPlayer.playedBytes = 0;
    audioPlayer.totalBytes = 0;
    
    // 重置进度条
    lv_bar_set_value(progress_bar, 0, LV_ANIM_OFF);
//    printf("上一首: %s\n", currentSong);
		if (song_name_label) {
        const char *name = get_filename_from_path(currentSong);
        lv_label_set_text(song_name_label, name);
    }
    playerState = PLAYER_PLAYING;

}

// 主播放循环
void audio_player_task(void) {
	  static uint32_t last_update = 0;
    static uint32_t last_time = 0;
    uint32_t now = lv_tick_get();
    
    // 限制调用频率，每30ms调用一次
//    if (now - last_time < 5) return;
//    last_time = now;
    
    if (playerState != PLAYER_PLAYING) return;
    
    // 如果文件没有打开，则打开文件
    if (!audioPlayer.isFileOpened) {
        FRESULT res = f_open(&audioPlayer.currentFile, currentSong, FA_READ);
        if (res != FR_OK) {
            playerState = PLAYER_STOPPED;
            return;
        }
				audioPlayer.totalBytes = f_size(&audioPlayer.currentFile);
        audioPlayer.playedBytes = 0;
        audioPlayer.currentPos = 0;
        audioPlayer.bufferPos = 0;
        audioPlayer.bufferSize = 0;
        audioPlayer.needNewData = 1;
        audioPlayer.isFileOpened = 1;
        
        // 初始化VS1053
        VS_Soft_Reset();
        VS_Restart_Play();
        VS_Set_All();
        VS_Set_Vol(220); // 设置音量
        VS_SPI_SpeedHigh();

				lv_bar_set_range(progress_bar, 0, 100);
        lv_bar_set_value(progress_bar, 0, LV_ANIM_OFF);

    }
    
    // 如果需要新数据，则从文件中读取
    if (audioPlayer.needNewData) {
        UINT br;
        FRESULT res = f_read(&audioPlayer.currentFile, audioPlayer.buffer, sizeof(audioPlayer.buffer), &br);
        if (res != FR_OK || br == 0) {
            // 文件结束，播放下一首
            f_close(&audioPlayer.currentFile);
            audioPlayer.isFileOpened = 0;
            play_next_song();
            return;
        }
        audioPlayer.bufferSize = br;
        audioPlayer.bufferPos = 0;
        audioPlayer.needNewData = 0;
    }
    
    // 发送32字节数据
    if (VS_Send_MusicData(audioPlayer.buffer + audioPlayer.bufferPos) == 0) {
        audioPlayer.bufferPos += 32;
				audioPlayer.playedBytes += 32;
            
            // 计算播放进度百分比
            uint8_t progress = 0;
            if (audioPlayer.totalBytes > 0) {
                progress = (audioPlayer.playedBytes * 100) / audioPlayer.totalBytes;
                
                // 确保不超过100%
                if (progress > 100) progress = 100;
							
								lv_bar_set_value(progress_bar, progress, LV_ANIM_OFF);
            }
            
            // 更新UI进度条
            
						
        if (audioPlayer.bufferPos >= audioPlayer.bufferSize) {
            audioPlayer.needNewData = 1;
        }
    }
  }
