#ifndef __READER_H__
#define __READER_H__

#include "lvgl.h"
#include "stdlib.h"
#include "ff.h"
#include "stdio.h"


static lv_obj_t *reader_title;
static lv_obj_t *text_cont;

void init_file_list(const char* path);
void load_file_content(const char *filename);
void next_file();
void prev_page();
void next_page();
static void reader_event_handler(lv_obj_t * obj, lv_event_t event);
void create_reader_page();
void txt_reader_init();
static void reader_back_action(lv_obj_t *btn, lv_event_t event);




#endif
