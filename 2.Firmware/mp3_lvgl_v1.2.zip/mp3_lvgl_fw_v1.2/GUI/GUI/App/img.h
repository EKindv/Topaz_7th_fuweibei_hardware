#ifndef __IMG_H__
#define __IMG_H__

#include "lvgl.h"
#include "stdlib.h"
#include "ff.h"
#include "stdio.h"

extern lv_obj_t *img_viewer_screen;
void create_image_viewer(void);

#endif
