#include "mic.h"
#include "stdio.h"
#include "ff.h"
#include "vs1053.h"
#include "time.h"
#include "fm33fk5xx_fl.h"
#include "homepage.h"
#include "style.h"
#include "mooncake_handler.h"

#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 320
#define BUFFER_SIZE 2048 // 2KB缓冲区
static uint8_t audio_buffer[BUFFER_SIZE];
static uint16_t buffer_index = 0;
lv_obj_t *status_label= NULL;     // ??????
lv_obj_t *rec_btn = NULL;
lv_task_t  *record_timer = NULL;
uint32_t record_seconds = 0;
FIL file;

WaveHeader_t wav_header;

lv_task_t *record_time_task = NULL;
lv_task_t *record_data_task = NULL;

static lv_coord_t orig_width = 60;
static lv_coord_t orig_height = 60;
static lv_coord_t orig_x = 0;
static lv_coord_t orig_y = 0;
static lv_style_t orig_style;

char filepath[50];
// 查找下一个可用的录音文件名
int find_next_filename(uint8_t *pname) {
    int index = 0;
    FRESULT res;
			while(index<0XFFFF){
				sprintf((char*)pname,"0:/RECORD/REC%05d.wav",index);
				res=f_open(&file,(const TCHAR*)pname,FA_READ);//尝试打开这个文件
				if(res==FR_NO_FILE)break;		//该文件名不存在=正是我们需要的.
				index++;
		}
    return index;
}

// 创建录音文件并写入WAV头
int create_rec_file() {
    uint8_t filename[30];
    int index = find_next_filename(filename);
    sprintf(filepath, "%s", filename); // 注意目录名一致性
    
    // 尝试多次打开文件
    FRESULT res;
    for(int i=0; i<5; i++) {
        res = f_open(&file, filepath, FA_WRITE | FA_CREATE_ALWAYS);
        if(res == FR_OK) break;
        FL_DelayMs(5);
    }
    if(res != FR_OK) {
        lv_label_set_text(status_label, "File create error");
        return 0;
    }
    // 初始化WAV头
    VS_RecorderWavInit(&wav_header);
    UINT bw;
    f_write(&file, &wav_header, sizeof(wav_header), &bw);
    return (bw == sizeof(wav_header));
}

// 更新录音文件头（录音完成后调用）
void update_wav_header() {
	// 移动文件指针到开头
    f_lseek(&file, 0);
    // 获取文件大小
    uint32_t  file_size = f_size(&file);
    // 更新WAV头中的文件大小信息
    wav_header.ChunkSize = file_size - 8;
    wav_header.Subchunk2Size = file_size - sizeof(WaveHeader_t);

    // 重新写入WAV头
    UINT bw;
    f_write(&file, &wav_header, sizeof(wav_header), &bw);
}

// 录音定时器回调（每秒更新一次）
void record_timer_cb(lv_task_t  * timer) {
    if (!is_recording) return;
    
    record_seconds++;
    
    // 每5秒自动保存一次（可选）
    if (record_seconds % 5 == 0) {
        f_sync(&file);
    }
}

// 录音数据采集定时器（每10ms采集一次）
void record_data_cb(lv_task_t  * timer) {
    if(!is_recording) return; 
    if(FL_GPIO_ReadInputPort(GPIOA) & FL_GPIO_PIN_6) 
    {
        uint16_t hdat1 = VS_RD_Reg(SPI_HDAT1);
        if ((hdat1 >= 256) && (hdat1 < 896)) {
            // 读取512字节（256个样本）
            for(int i=0; i<256; i++) {
                if(buffer_index >= BUFFER_SIZE) {
                    UINT bw;
                    f_write(&file, audio_buffer, BUFFER_SIZE, &bw);
                    buffer_index = 0;
                }
                
                uint16_t data = VS_RD_Reg(SPI_HDAT0);
                audio_buffer[buffer_index++] = data & 0xFF;
                audio_buffer[buffer_index++] = data >> 8;
            }
        }
    }
}

void audio_capture_handler(void)
{
    // 10ms采样周期控制
    if(last_time <3) 
		{
			last_time ++;
			return;
		}
		last_time = 0;
    if(is_recording)
    {
        uint16_t hdat1 = VS_RD_Reg(SPI_HDAT1);
        
        // 精确缓冲区状态检测（正点原子方案）
        if((hdat1 >= 256) && (hdat1 < 896))
        {
            UINT bw;
            uint16_t w;
            
            // 直接读取512字节
            for(int i = 0; i < 256; i++)
            {
                w = VS_RD_Reg(SPI_HDAT0);
                // 小缓冲直接写入（512字节）
                audio_buffer[2*i] = w & 0xFF;
                audio_buffer[2*i+1] = w >> 8;
            }
            
            // 立即写入SD卡
            f_write(&file, audio_buffer, 512, &bw);
            
            // 更新录音时间计数器
            record_seconds++;
        }
    }
}

// 开始录音
void start_recording() {
    if (is_recording) return;
    uint16_t recagc = 1024*30;					//默认增益为4 
		VS_HD_Reset();
    // 初始化录音功能（自动增益）
    VS_RecorderInit(recagc);
    uint16_t mode_reg = VS_RD_Reg(SPI_MODE);
		uint16_t ai_ctrl3 = VS_RD_Reg(SPI_AICTRL3);
    // 创建录音文件
    if (!create_rec_file()) {
        lv_label_set_text(status_label, "Create file error!");
        return;
    }
    
    // 开始录音
 //   VS_Start_Recording();
		VS_WR_Cmd(SPI_WRAMADDR, 0xc045);
		VS_WR_Cmd(SPI_WRAM, 0xfefe);
		VS_SPI_SpeedHigh();
    // 重置录音时间
    record_seconds = 0;   
    // 更新状态
    is_recording = true;
    update_recording_state(true);
}

// 停止录音
void stop_recording() {
    if (!is_recording) return;
    
    // 停止录音
    VS_Stop_Recording();
    is_recording = false;    
//    // 停止定时器
//    lv_task_del(record_timer);
        // 修改任务删除代码
    if (record_time_task) {
        lv_task_del(record_time_task);
        record_time_task = NULL;
    }
    if (record_data_task) {
        lv_task_del(record_data_task);
        record_data_task = NULL;
    }
    // 更新WAV文件头
    update_wav_header();
    
    // 关闭文件
    f_close(&file);
    
    // 更新状态

    update_recording_state(false);
}

// 录音按钮事件处理
void recorder_btn_handler(lv_obj_t * obj, lv_event_t event) {
    if (event == LV_EVENT_CLICKED) {
        if (!is_recording) {
            start_recording();
            
            // 设置为圆角矩形状态
            lv_obj_set_size(rec_btn, 28, 28);  // 60*0.8=48
            // 计算在容器内的新位置（容器70x70，按钮48x48，居中）
            lv_obj_set_x(rec_btn, (70 - 28) / 2);
            lv_obj_set_y(rec_btn, (70 - 28) / 2);
            
            // 修改圆角
            lv_style_t *style = (lv_style_t *)lv_btn_get_style(rec_btn, LV_BTN_STYLE_REL);
            style->body.radius = 5;
            style = (lv_style_t *)lv_btn_get_style(rec_btn, LV_BTN_STYLE_PR);
            style->body.radius = 5;
            
        } else {
            stop_recording();
            
            // 恢复为圆形状态
            lv_obj_set_size(rec_btn, 50, 50);
            // 恢复在容器内的原始位置（容器70x70，按钮60x60，居中）
            lv_obj_set_x(rec_btn, (70 - 50) / 2);
            lv_obj_set_y(rec_btn, (70 - 50) / 2);
            
            // 修改圆角为圆形
            lv_style_t *style = (lv_style_t *)lv_btn_get_style(rec_btn, LV_BTN_STYLE_REL);
            style->body.radius = LV_RADIUS_CIRCLE;
            style = (lv_style_t *)lv_btn_get_style(rec_btn, LV_BTN_STYLE_PR);
            style->body.radius = LV_RADIUS_CIRCLE;
        }
        
        // 强制重绘按钮
        lv_obj_invalidate(rec_btn);
    }
}

void create_recorder_ui() {
			LV_FONT_DECLARE(mic_28);
    // 创建全屏透明容器
    mic_screen = lv_cont_create(lv_scr_act(), NULL);
    lv_obj_set_size(mic_screen, SCREEN_WIDTH, SCREEN_HEIGHT);
    lv_obj_set_style(mic_screen, &lv_style_transp_fit);
    
    // 左上角返回按钮
    lv_obj_t *back_btn = lv_btn_create(mic_screen, NULL);
    lv_obj_set_pos(back_btn, 10, 10);
    lv_obj_set_size(back_btn, 40, 30);
	  lv_btn_set_style(back_btn, LV_BTN_STYLE_REL, &style_btn);
    lv_btn_set_style(back_btn, LV_BTN_STYLE_PR, &style_btn_pressed);
	
    lv_obj_t *back_label = lv_label_create(back_btn, NULL);
    lv_label_set_text(back_label, LV_SYMBOL_LEFT);
    lv_obj_align(back_label, NULL, LV_ALIGN_CENTER, 0, 0);
	
		lv_obj_set_style(back_label, &style_font_secondary);	
    lv_obj_set_event_cb(back_btn,recoder_back_action);
    // 标题
    lv_obj_t *title = lv_label_create(mic_screen, NULL);
    lv_label_set_text(title, "MIC");
    lv_obj_set_pos(title, 60, 15);

    lv_label_set_style(title, LV_LABEL_STYLE_MAIN, &style_font_secondary);
		//装饰线
    lv_obj_t *line = lv_line_create(mic_screen, NULL);
		static lv_point_t line_points[] = {
    {10, 45},  // 起点坐标 (x, y)
    {230, 45}  // 终点坐标 (x, y)
		};
				// 应用样式
		lv_line_set_points(line, line_points, 2);    // 设置点数组和点数量
		lv_line_set_style(line, LV_LINE_STYLE_MAIN, &line_style);
    // 状态信息标签
    status_label = lv_label_create(mic_screen, NULL);
    lv_label_set_text(status_label, "Ready...");
    lv_obj_set_pos(status_label, 20, 50);
		
    lv_label_set_style(status_label, LV_LABEL_STYLE_MAIN, &style_font_secondary);
    
    // 底部控制栏（灰色长条）
    lv_obj_t *control_bar = lv_cont_create(mic_screen, NULL);
    lv_obj_set_pos(control_bar, 0, SCREEN_HEIGHT - 90); // 位于屏幕底部
    lv_obj_set_size(control_bar, SCREEN_WIDTH, 90);
    
    // 控制栏样式（灰色背景）
    static lv_style_t bar_style;
    lv_style_copy(&bar_style, &lv_style_plain);
    bar_style.body.main_color = LV_COLOR_MAKE(73, 82, 103);
    bar_style.body.grad_color = LV_COLOR_MAKE(73, 82, 103);
    bar_style.body.border.width = 0;
    bar_style.body.radius = 0;
    lv_cont_set_style(control_bar, LV_CONT_STYLE_MAIN, &bar_style);
    
    // 录音按钮容器（提供白色边框效果）
    lv_obj_t *btn_cont = lv_cont_create(control_bar, NULL);
    lv_obj_set_pos(btn_cont, (SCREEN_WIDTH - 80) / 2, 10); // 居中
    lv_obj_set_size(btn_cont, 70, 70);
    
    // 按钮容器样式（白色边框）
    static lv_style_t btn_cont_style;
    lv_style_copy(&btn_cont_style, &lv_style_plain);
    btn_cont_style.body.main_color = LV_COLOR_MAKE(73, 82, 103);
    btn_cont_style.body.grad_color = LV_COLOR_MAKE(73, 82, 103);
    btn_cont_style.body.radius = LV_RADIUS_CIRCLE; // 圆形
    btn_cont_style.body.border.width = 5;
    btn_cont_style.body.border.color = LV_COLOR_WHITE;
    lv_cont_set_style(btn_cont, LV_CONT_STYLE_MAIN, &btn_cont_style);
    
    // 录音按钮（红色圆形）
    rec_btn = lv_btn_create(btn_cont, NULL);
    lv_obj_set_size(rec_btn, 50, 50); // 尺寸小于容器，形成边框效果
    lv_obj_align(rec_btn, NULL, LV_ALIGN_CENTER, 0, 0);
    
    // 按钮样式（红色）
    static lv_style_t rec_btn_style;
    lv_style_copy(&rec_btn_style, &lv_style_plain);
    rec_btn_style.body.main_color = LV_COLOR_RED;
    rec_btn_style.body.grad_color = LV_COLOR_RED;
    rec_btn_style.body.radius = LV_RADIUS_CIRCLE; // 圆形
    rec_btn_style.body.border.width = 0;
	
		
    lv_btn_set_style(rec_btn, LV_BTN_STYLE_REL, &rec_btn_style);
    lv_btn_set_style(rec_btn, LV_BTN_STYLE_PR, &rec_btn_style);
    // 添加按钮事件回调
     lv_obj_set_event_cb(rec_btn, recorder_btn_handler);
}

// 更新录音状态显示
void update_recording_state(bool is_recording) {
    if (is_recording) {
        lv_label_set_text(status_label, "Recording...");
    } else {
        lv_label_set_text(status_label, "Recording saved");
    }
}


static void recoder_back_action(lv_obj_t *btn, lv_event_t event) {
    if(event == LV_EVENT_CLICKED) {
        if(mic_screen) {
            lv_obj_del(mic_screen);
            mic_screen = NULL;
        }
        
        // 显示主界面
        if (home_screen) {
            lv_obj_set_hidden(home_screen, false);
            current_screen = home_screen;
        } else {
            // 创建主页
            scrollicon();
        }
    }
}
