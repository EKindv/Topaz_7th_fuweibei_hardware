#ifndef __STYLE_H__
#define __STYLE_H__

#include "lvgl.h"

// 声明全局样式变量

extern lv_style_t style_font_primary;   // 主要字体样式
extern lv_style_t style_font_primary_dark;   // 主要字体样式
extern lv_style_t style_font_secondary; // 次要字体样式
extern lv_style_t style_font_secondary_dark; // 次要字体样式
extern lv_style_t style_font_cn;
extern lv_style_t style_btn;            // 按钮基础样式
extern lv_style_t style_btn_pressed;    // 按钮按下样式
extern lv_style_t style_progress_bg;    // 进度条背景样式
extern lv_style_t style_progress_indic; // 进度条指示器样式
extern lv_style_t line_style; 					// 装饰线样式

// 初始化全局样式函数
void init_global_styles(void);

#endif
