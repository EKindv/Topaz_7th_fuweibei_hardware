#include "lvgl.h"
#include "style.h"

// 定义全局样式变量
lv_style_t style_font_primary;
lv_style_t style_font_primary_dark;
lv_style_t style_font_secondary;
lv_style_t style_font_secondary_dark;
lv_style_t style_font_cn;
lv_style_t style_btn;
lv_style_t style_btn_pressed;
lv_style_t style_progress_bg;
lv_style_t style_progress_indic;
lv_style_t line_style;

void init_global_styles(void) {
	
		LV_FONT_DECLARE(myFont_12);
		lv_obj_t *scr = lv_scr_act();
		static lv_style_t root_style;
		lv_style_copy(&root_style, &lv_style_plain);
		root_style.body.main_color = LV_COLOR_MAKE(49,55,69);
		root_style.body.grad_color = LV_COLOR_MAKE(49,55,69);
		lv_obj_set_style(scr, &root_style);
	
    /* 主要字体样式（大字体） */
    lv_style_copy(&style_font_primary, &lv_style_plain);
    style_font_primary.text.color = LV_COLOR_MAKE(197, 199, 150);
    style_font_primary.text.font = &lv_font_roboto_28; // 使用合适的字体

    /* 主要字体样式（大字体_深色） */
    lv_style_copy(&style_font_primary_dark,&lv_style_plain);
    style_font_primary_dark.text.color = LV_COLOR_MAKE(49,55,69);
    style_font_primary_dark.text.font = &lv_font_roboto_28; // 使用合适的字体
	
    /* 次要字体样式（小字体） */
    lv_style_copy(&style_font_secondary, &lv_style_plain);
    style_font_secondary.text.color = LV_COLOR_WHITE;
    style_font_secondary.text.font = &lv_font_roboto_16;
		
		lv_style_copy(&style_font_secondary_dark, &lv_style_plain);
    style_font_secondary_dark.text.color = LV_COLOR_MAKE(49,55,69);
    style_font_secondary_dark.text.font = &lv_font_roboto_16;
		
		/*中文字体*/
    lv_style_copy(&style_font_cn, &lv_style_plain);
    style_font_cn.text.color = LV_COLOR_WHITE;
    style_font_cn.text.font = &myFont_12;
		
    /* 按钮基础样式 */
    lv_style_copy(&style_btn, &lv_style_btn_rel);
    style_btn.body.main_color = LV_COLOR_MAKE(137, 137, 137);
    style_btn.body.grad_color = LV_COLOR_MAKE(137, 137, 137);
    style_btn.body.radius = 8; // 圆角半径
    style_btn.text.color = LV_COLOR_WHITE;
    
    /* 按钮按下样式 */
    lv_style_copy(&style_btn_pressed, &style_btn);
    style_btn_pressed.body.main_color = LV_COLOR_MAKE(112, 112, 112); // 深一点的蓝色
    style_btn_pressed.body.grad_color = LV_COLOR_MAKE(112, 112, 112);

    /* 进度条背景样式 */
    lv_style_copy(&style_progress_bg, &lv_style_pretty);
    style_progress_bg.body.main_color = LV_COLOR_MAKE(220, 220, 220);
    style_progress_bg.body.grad_color = LV_COLOR_MAKE(220, 220, 220);
    style_progress_bg.body.radius = 10; // 圆角

    /* 进度条指示器样式 */
    lv_style_copy(&style_progress_indic, &lv_style_pretty);
    style_progress_indic.body.main_color = LV_COLOR_MAKE(70, 130, 180); // 与按钮相同
    style_progress_indic.body.grad_color = LV_COLOR_MAKE(70, 130, 180);
    style_progress_indic.body.radius = 10; // 圆角
		
		/* 装饰线样式 */
		lv_style_copy(&line_style, &lv_style_plain);
		line_style.line.width = 2;                  // 线宽
		line_style.line.color = LV_COLOR_MAKE(197, 199, 150);      // 颜色
		line_style.line.rounded = 1;                // 圆角端点
}
