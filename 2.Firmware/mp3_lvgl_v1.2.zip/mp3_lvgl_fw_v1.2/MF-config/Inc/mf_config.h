/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : mf_config.h
  * @brief          : Header for mf_config.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) [2019] [Fudan Microelectronics]
  * THIS SOFTWARE is licensed under the Mulan PSL v1.
  * can use this software according to the terms and conditions of the Mulan PSL v1.
  * You may obtain a copy of Mulan PSL v1 at:
  * http://license.coscl.org.cn/MulanPSL
  * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
  * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
  * PURPOSE.
  * See the Mulan PSL v1 for more details.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MF_CONFIG_H
#define __MF_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#if defined(FM33FK5XX)
#include "fm33fk5xx_fl.h"

//λ������,ʵ��51���Ƶ�GPIO���ƹ���
//����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
//IO�ڵ�ַӳ��
#define GPIOA_OD_Addr    (GPIOA_BASE+0x10) 
#define GPIOB_OD_Addr    (GPIOB_BASE+0x10)
#define GPIOC_OD_Addr    (GPIOC_BASE+0x10)
#define GPIOD_OD_Addr    (GPIOD_BASE+0x10) 
#define GPIOE_OD_Addr    (GPIOE_BASE+0x10)
#define GPIOF_OD_Addr    (GPIOF_BASE+0x10)   

#define GPIOA_ID_Addr    (GPIOA_BASE+0x1c)
#define GPIOB_ID_Addr    (GPIOB_BASE+0x1c)
#define GPIOC_ID_Addr    (GPIOC_BASE+0x1c) 
#define GPIOD_ID_Addr    (GPIOD_BASE+0x1c)
#define GPIOE_ID_Addr    (GPIOE_BASE+0x1c)
#define GPIOF_ID_Addr    (GPIOF_BASE+0x1c) 
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOE_OD_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_ID_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_OD_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_ID_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_OD_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_ID_Addr,n)  //���� 

#define PDout(n)   BIT_ADDR(GPIOD_OD_Addr,n)  //��� 
#define PDin(n)    BIT_ADDR(GPIOD_ID_Addr,n)  //���� 

#define PEout(n)   BIT_ADDR(GPIOE_OD_Addr,n)  //��� 
#define PEin(n)    BIT_ADDR(GPIOE_ID_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_OD_Addr,n)  //��� 
#define PFin(n)    BIT_ADDR(GPIOF_ID_Addr,n)  //����

/////////////////////////////////////////////////////////////////
//Ex_NVIC_Configר�ö���
#define GPIO_A 0
#define GPIO_B 1
#define GPIO_C 2
#define GPIO_D 3
#define GPIO_E 4
#define GPIO_F 5
#define GPIO_G 6 
#define FTIR   1  //�½��ش���
#define RTIR   2  //�����ش���
#endif
/* Exported functions prototypes ---------------------------------------------*/
void MF_Clock_Init(void);
void MF_SystemClock_Config(void);
void MF_Config_Init(void);
void Error_Handler(void);
void MF_PMU_Init(void);
void GPTIM0_Init(void);
void GPTIM1_Init(void);
void GPTIM2_Init(void);
void MF_OUTRTC_Data_Out_Init(void);
void MF_OUTRTC_Data_In_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* __MF_CONFIG_H */

/************************ (C) COPYRIGHT FMSH *****END OF FILE****/
