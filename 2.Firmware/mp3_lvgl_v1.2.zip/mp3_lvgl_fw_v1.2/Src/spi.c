#include "spi.h"

#define TIMEOUT_VAL     (0xFFFFFFFFUL)
/**
  * @brief  SPI读写数据
  * @param  data: 写数据
  * @retval data: 读数据
  */

uint32_t SpiWriteAndRead(SPI_Type *SPIx, uint32_t data)
{
    uint32_t timeout = 0;

    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_LOW);

    FL_SPI_WriteTXBuff(SPIx, data);

    do
    {
        timeout++;
    } while(!FL_SPI_IsActiveFlag_TXBuffEmpty(SPIx) && timeout < TIMEOUT_VAL);

    timeout = 0;
    do
    {
        timeout++;
    } while(!FL_SPI_IsActiveFlag_RXBuffFull(SPIx) && timeout < TIMEOUT_VAL);

    data = FL_SPI_ReadRXBuff(SPIx);

    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_HIGH);

    return data;
}

/**
  * @brief  SPI写数据
  * @param  data:   数据指针
  *         length: 数据长度
  * @retval void
  */
void SpiWriteData(SPI_Type *SPIx, uint8_t *data, uint16_t length)
{
    uint32_t timeout;
    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_LOW);

    while(length--)
    {
        FL_SPI_WriteTXBuff(SPIx, *(data++));

        // 等待发送缓存空
        timeout = 0;
        do
        {
            timeout++;
        } while(!FL_SPI_IsActiveFlag_TXBuffEmpty(SPIx) && timeout < TIMEOUT_VAL);

        timeout = 0;
        do
        {
            timeout++;
        } while(!FL_SPI_IsActiveFlag_RXBuffFull(SPIx) && timeout < TIMEOUT_VAL);

        FL_SPI_ReadRXBuff(SPIx);
    }
    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_HIGH);

}

/**
  * @brief  SPI读数据
  * @param  data:   数据指针
  *         length: 数据长度
  * @retval void
  */
void SpiReadData(SPI_Type *SPIx, uint8_t *data, uint16_t length)
{
    uint32_t timeout;

    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_LOW);

    while(length--)
    {
        FL_SPI_WriteTXBuff(SPIx, 0x55);
        timeout = 0;
        do
        {
            timeout++;
        } while(!FL_SPI_IsActiveFlag_RXBuffFull(SPIx) && timeout < TIMEOUT_VAL);

        *data = FL_SPI_ReadRXBuff(SPIx);
        data++;
    }

    FL_SPI_SetSSNPin(SPIx, FL_SPI_SSN_HIGH);

}
