#include "EPSC.h"

lcd_struct lcdstr;

#if 1
static void DelayMs(uint32_t ms)
{
    ms=ms*6500;                  
    for(uint32_t i=0; i<ms; i++);
}
#endif

//写入要写的寄存器序号
void LCD_WR_REG(uint16_t regval)
{
    LCD->LCD_REG = regval;
}
//写LCD数据
//data:要写入的值
void LCD_WR_DATA(uint16_t data)
{
    LCD->LCD_RAM = data;
}
//读LCD数据
//返回值:读到的值
uint16_t LCD_RD_DATA(void)
{
    uint16_t ram;           //防止被优化
    ram = LCD->LCD_RAM;
    return ram;
}
//写寄存器
//LCD_Reg:寄存器地址
//LCD_RegValue:要写入的数据
void LCD_WriteReg(uint16_t LCD_Reg, uint16_t LCD_RegValue)
{
    LCD->LCD_REG = LCD_Reg;
    LCD->LCD_RAM = LCD_RegValue;
}

//读寄存器
//LCD_Reg:寄存器地址
//返回值:读到的数据
uint16_t LCD_ReadReg(uint16_t LCD_Reg)
{
    LCD_WR_REG(LCD_Reg);        //写入要读的寄存器序号
    FL_DelayUs(5);
    return LCD_RD_DATA();       //返回读到的值
}

//开始写GRAM
void LCD_WriteRAM_Prepare(void)
{
    LCD->LCD_REG = 0x2C;
}

//设置光标位置
//Xpos:横坐标
//Ypos:纵坐标
void LCD_SetCursor(uint16_t Xpos, uint16_t Ypos)
{
    LCD_WR_REG(lcdstr.setxcmd);
    LCD_WR_DATA(Xpos >> 8);
    LCD_WR_REG(lcdstr.setxcmd + 1);
    LCD_WR_DATA(Xpos & 0XFF);
    LCD_WR_REG(lcdstr.setycmd);
    LCD_WR_DATA(Ypos >> 8);
    LCD_WR_REG(lcdstr.setycmd + 1);
    LCD_WR_DATA(Ypos & 0XFF);
}
void setCursor(uint16_t x, uint16_t y, uint16_t width, uint16_t height)
{             
    LCD_WR_REG (0X2A);
    LCD_WR_DATA(x>>8);
    LCD_WR_DATA(x&0xFF);
    LCD_WR_DATA((x+width-1)>>8);
    LCD_WR_DATA((x+width-1)&0xFF);     
    
    LCD_WR_REG (0X2B); 
    LCD_WR_DATA(y>>8);
    LCD_WR_DATA(y&0xFF);
    LCD_WR_DATA((y+height-1)>>8);
    LCD_WR_DATA((y+height-1)&0xFF);     

    LCD_WR_REG(0X2C);     
}     

//清屏函数
//color:要清屏的填充色
void LCD_Clear(uint16_t color)
{
    uint32_t index = 0;
    uint32_t totalpoint = lcdstr.width;
    totalpoint *= lcdstr.height;        //得到总点数
    setCursor(0x00, 0x00,240,320); //设置光标位置
    LCD_WriteRAM_Prepare();             //开始写入GRAM
    for(index = 0; index < totalpoint; index++)
    {
        LCD->LCD_RAM = color;
    }
}

void LCD_Config(void)
{
    //³¢ÊÔ9341 IDµÄ¶ÁÈ¡        
    LCD_WR_REG(0XD3);            // Ö¸Áî£º¶ÁID               
    LCD_RD_DATA();             // µÚ1¸ö²ÎÊý£ºdummy        
    LCD_RD_DATA();               // µÚ2¸ö²ÎÊý£ºIC°æ±¾ºÅ
    lcdstr.id=LCD_RD_DATA();     // µÚ3¸ö²ÎÊý£ºICÃû×Ö(93)    
       lcdstr.id<<=8;
    lcdstr.id|=LCD_RD_DATA();    // µÚ4¸ö²ÎÊý£ºICÃû×Ö(41)    
    if(lcdstr.id !=0x00009341)    // 9341³õÊ¼»¯Ê§°Ü
		{
				FL_GPIO_SetOutputPin(GPIOF,FL_GPIO_PIN_5);
        return;                // ×¢Òâ£ºÈç¹ûFSMCÅäÖÃ²»ÕýÈ·£¬ÓÐ¿ÉÄÜ¿ÉÏÔÊ¾£¬µ«Ë¢ÐÂËÙ¶ÈÂý£¬ÇÒ¶ÁÈ¡²»µ½ÕýÈ·ÐÍºÅ
    }
    // Power control B (CFh) 
    LCD_WR_REG ( 0xCF  );
    LCD_WR_DATA ( 0x00  );
    LCD_WR_DATA ( 0xC1  ); //-81
    LCD_WR_DATA ( 0x30  );    
    // Power on sequence control (EDh)
    LCD_WR_REG ( 0xED );
    LCD_WR_DATA ( 0x64 );
    LCD_WR_DATA ( 0x03 );
    LCD_WR_DATA ( 0x12 );
    LCD_WR_DATA ( 0x81 );    
    // Driver timing control A (E8h)
    LCD_WR_REG ( 0xE8 ); //
    LCD_WR_DATA ( 0x85 );
    LCD_WR_DATA ( 0x10 );
    LCD_WR_DATA ( 0x7A ); //-78    
    // Power control A (CBh) 
    LCD_WR_REG ( 0xCB );
    LCD_WR_DATA ( 0x39 );
    LCD_WR_DATA ( 0x2C );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x34 );
    LCD_WR_DATA ( 0x02 );    
    // Pump ratio control (F7h)
    LCD_WR_REG ( 0xF7 );
    LCD_WR_DATA ( 0x20 );        
    // Driver timing control B 
    LCD_WR_REG ( 0xEA );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x00 );            
    // Frame Rate Control (In Normal Mode/Full Colors) (B1h) */
    LCD_WR_REG ( 0xB1 );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x1A );  //-1B    
    //  Display Function Control (B6h) */
    LCD_WR_REG ( 0xB6 );
    LCD_WR_DATA ( 0x0A );
    LCD_WR_DATA ( 0xA2 );    
    // Power Control 1 (C0h) 
    LCD_WR_REG ( 0xC0 );
    LCD_WR_DATA ( 0x1B ); //-35    
    // Power Control 2 (C1h) 
    LCD_WR_REG ( 0xC1 );
    LCD_WR_DATA ( 0x01 ); //-11    
    // VCOM ¿ØÖÆ 1 (C5h) 
    LCD_WR_REG ( 0xC5 );
    LCD_WR_DATA ( 0x30 );  // 45
    LCD_WR_DATA ( 0x30 );  // 45    
    // VCOM ¿ØÖÆ 2 (C7h) 
    LCD_WR_REG ( 0xC7 );
    LCD_WR_DATA ( 0xB7 );  //-A2    
    // Ê¹ÄÜ3 Ù¤Âí¿ØÖÆ (F2h) 
    LCD_WR_REG ( 0xF2 );
    LCD_WR_DATA ( 0x00 );    
    // Ù¤ÂíÉèÖÃ (26h)
    LCD_WR_REG ( 0x26 );
    LCD_WR_DATA ( 0x01 );    
    // Õý¼«Ù¤ÂíÐ£×¼ (E0H)
    LCD_WR_REG ( 0xE0 ); 
    LCD_WR_DATA ( 0x0F );
    LCD_WR_DATA ( 0x2A ); // 26
    LCD_WR_DATA ( 0x28 ); // 24
    LCD_WR_DATA ( 0x08 ); //0B
    LCD_WR_DATA ( 0x0E );
    LCD_WR_DATA ( 0x08 ); // 09
    LCD_WR_DATA ( 0x54 );
    LCD_WR_DATA ( 0xA9 ); // A8
    LCD_WR_DATA ( 0x43 ); // 46
    LCD_WR_DATA ( 0x0A ); // 0c
    LCD_WR_DATA ( 0x0F ); // 17
    LCD_WR_DATA ( 0x00 ); // 00
    LCD_WR_DATA ( 0x00 ); // 00
    LCD_WR_DATA ( 0x00 ); // 00
    LCD_WR_DATA ( 0x00 );     
    // ¸º¼«Ù¤ÂíÐ£×¼ (E1h) 
    LCD_WR_REG ( 0XE1 );  
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x15 ); // 19
    LCD_WR_DATA ( 0x17 ); // 1B
    LCD_WR_DATA ( 0x07 ); // 04
    LCD_WR_DATA ( 0x11 ); // 10
    LCD_WR_DATA ( 0x06 ); // 07
    LCD_WR_DATA ( 0x2B ); // 2A
    LCD_WR_DATA ( 0x56 ); // 47
    LCD_WR_DATA ( 0x3C ); // 39
    LCD_WR_DATA ( 0x05 ); // 03
    LCD_WR_DATA ( 0x10 ); // 06
    LCD_WR_DATA ( 0x0F ); // 06
    LCD_WR_DATA ( 0x3F ); // 30
    LCD_WR_DATA ( 0x3F ); // 38
    LCD_WR_DATA ( 0x0F ); //     
    // ÁÐµØÖ·ÉèÖÃ
    LCD_WR_REG ( 0x2A );     
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0xEF );    
    // Ò³µØÖ·ÉèÖÃ                 
    LCD_WR_REG ( 0x2B ); 
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x00 );
    LCD_WR_DATA ( 0x01 );
    LCD_WR_DATA ( 0x3F );    
    // ÏñËØ¸ñÊ½ÉèÖÃ (3Ah)
    LCD_WR_REG ( 0x3a );    // ÏñËØ¸ñÊ½ÉèÖÃ
    LCD_WR_DATA ( 0x55 );   // 16Î»½Ó¿Ú£¬16Î»Êý¾Ý    
    // ÍË³öË¯ÃßÄ£Ê½ (11h) 
    LCD_WR_REG ( 0x11 );      // µÈ´ý5ms´ýµçÂ·ÎÈ¶¨£¬ÔÙÖ´ÐÐÆäËüÖ¸Áî
    FL_DelayMs(10);                
    // ´ò¿ªÏÔÊ¾(29h) 
    LCD_WR_REG ( 0x29 );    // ²»»á¸Ä±äÖ¡´æ´¢Æ÷Êý¾Ý        
    
    LCD_DisplayDir(LCD_DIR);    // ÉèÖÃÏÔÊ¾·½Ïò
    LCD_Fill(0, 0, lcdstr.width-1, lcdstr.height-1, BLACK);

    lcdstr.FlagInit =1;    

}
void LCD_DisplayDir(uint8_t scanDir)
{
    uint16_t regval=0;
    
    if(scanDir==0||scanDir==3)       // ÊúÆÁ
    {
        lcdstr.dir=0;          
        lcdstr.width  = LCD_WIDTH;
        lcdstr.height = LCD_HIGH ;
    }
    if(scanDir==5 || scanDir==6)   // ºáÆÁ
    {                      
        lcdstr.dir=1;          
        lcdstr.width  = LCD_HIGH;
        lcdstr.height = LCD_WIDTH;
    }         
    
    if(scanDir==0) regval|=(0<<7)|(0<<6)|(0<<5);
    if(scanDir==3) regval|=(1<<7)|(1<<6)|(0<<5);
    if(scanDir==5) regval|=(0<<7)|(1<<6)|(1<<5);
    if(scanDir==6) regval|=(1<<7)|(0<<6)|(1<<5);       
    LCD_WR_REG (0X36);
    LCD_WR_DATA(regval|0x08);          // 
}    
void LCD_DisplayOn(void)
{                       
    LCD_WR_REG(0X29);
}     
void LCD_Fill(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color)
{          
    uint32_t num = width * height;
    setCursor(x, y, width, height);
    while(num--)
        LCD_WR_DATA(color);
}  
void LCD_Color_Fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t *color)
{
    // 自动处理反向坐标
    if(sx > ex) { uint16_t tmp = sx; sx = ex; ex = tmp; }
    if(sy > ey) { uint16_t tmp = sy; sy = ey; ey = tmp; }

    // 计算实际填充尺寸
    uint16_t width = ex - sx + 1;
    uint16_t height = ey - sy + 1;
    uint32_t total_pixels = (uint32_t)width * height;

    // 1. 设置填充区域范围（类似LCD_Clear的光标设置）
    setCursor(sx, sy,width,height);          // 设置起始坐标（若需更精确，需分X/Y范围）
    // 或使用底层命令直接配置区域（需根据LCD控制器指令）
    // 发送X范围命令 0x2A，参数 sx 和 ex
    // 发送Y范围命令 0x2B，参数 sy 和 ey

    // 2. 进入GRAM连续写入模式
    LCD_WriteRAM_Prepare();         // 发送GRAM写入命令（如 0x2C）

    // 3. 批量写入颜色数组
    for(uint32_t i = 0; i < total_pixels; i++) 
    {
        LCD->LCD_RAM = color[i];    // 连续写入，硬件自动递增地址
    }
}
void LCD_DrawPoint(uint16_t x, uint16_t y, uint16_t color)
{
    setCursor(x,y, 1, 1);        //ÉèÖÃ¹â±êÎ»ÖÃ 
    LCD_WR_DATA(color); 
}    