#include "I2C.h"
#include "EPSC.h"

#define  I2C_TIMEOUT   0x7FFFFU                    //I2C超时时间

#define I2CREAD     1                                                         //I2C读操作
#define I2CWRITE    0                                                         //I2C写操作

#define STARTBIT    0
#define RESTARTBIT  1
#define STOPBIT     2



static uint8_t I2C_Send_Bit(I2C_Type *I2Cx, uint8_t BIT_def)
{
    uint8_t result = 1;
    uint32_t Start_Flag, Stop_Flag, Restart_Flag;
    uint32_t Counter;
    switch(BIT_def)
    {
        case STARTBIT:
            FL_I2C_Master_EnableI2CStart(I2Cx);                               //产生start信号

            Counter = 0;
            do
            {
                Start_Flag = FL_I2C_Master_IsActiveFlag_Start(I2Cx);
                Counter++;
            } while((Counter != I2C_TIMEOUT) && (Start_Flag == 0U));           //等待转换完成

            if(Start_Flag == 0x01)
            {
                result = 0;
            }
            else
            {
                result = 1;
            }
            break;

        case RESTARTBIT:
            FL_I2C_Master_EnableI2CRestart(I2Cx);                             //产生restart信号

            Counter = 0;
            do
            {
                Restart_Flag = FL_I2C_Master_IsActiveFlag_Start(I2Cx);
                Counter++;
            } while((Counter != I2C_TIMEOUT) && (Restart_Flag == 0U));         //等待转换完成

            if(Restart_Flag == 0x01)
            {
                result = 0;
            }
            else
            {
                result = 1;
            }
            break;

        case STOPBIT:
            FL_I2C_Master_EnableI2CStop(I2Cx);                                //产生stop信号

            Counter = 0;
            do
            {
                Stop_Flag = FL_I2C_Master_IsActiveFlag_Stop(I2Cx);
                Counter++;
            } while((Counter != I2C_TIMEOUT) && (Stop_Flag == 0U));           //等待转换完成

            if(Stop_Flag == 0x01)
            {
                result = 0;
            }
            else
            {
                result = 1;
            }
            break;
        default:
            result = 1;
            break;
    }

    return result; //ok

}

 uint8_t I2C_Send_Byte(I2C_Type *I2Cx, uint8_t x_byte)
{
    uint8_t result = 1;
    uint32_t TX_Flag;
    uint32_t Counter;

    FL_I2C_Master_WriteTXBuff(I2Cx, x_byte);                                  //发送数据

    Counter = 0;
    do
    {
        TX_Flag = FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx);
        Counter++;
    } while((Counter != I2C_TIMEOUT) && (TX_Flag == 0U));                      //等待转换完成

    if(TX_Flag == 0x01)
    {
        FL_I2C_Master_ClearFlag_TXComplete(I2Cx);
    }
    else
    {
        return 1;
    }

    if(FL_I2C_Master_IsActiveFlag_NACK(I2Cx) == 0)                            //判断接收到ACK or NACK
    {
        result = 0;
    }

    else
    {
        FL_I2C_Master_ClearFlag_NACK(I2Cx);
        result = 1;
    }

    return result; //ok
}

static uint8_t I2C_Receive_Byte(I2C_Type *I2Cx, uint8_t *x_byte)
{
    uint32_t Counter;
    uint32_t RX_Flag;
    uint8_t result = 1;
    FL_I2C_Master_EnableRX(I2Cx);                                             //配置接收使能

    Counter = 0;
    do
    {
        RX_Flag = FL_I2C_Master_IsActiveFlag_RXComplete(I2Cx);
        Counter++;
    } while((Counter != I2C_TIMEOUT) && (RX_Flag == 0U));                      //等待接收完成

    if(RX_Flag == 0x01)
    {
        FL_I2C_Master_ClearFlag_RXComplete(I2Cx);
    }
    else
    {
        return 1;
    }

    *x_byte = (uint8_t)(FL_I2C_Master_ReadRXBuff(I2Cx) & 0xFFU);
    result  = 0;

    return result;

}

static uint8_t Sendaddr(I2C_Type *I2Cx, uint8_t Device, uint16_t Addr, uint8_t AddrLen, uint8_t Opt)
{
    uint8_t result, Devi_Addr;

    Devi_Addr = Device;

    /*-------------- start bit ---------------*/
    result = I2C_Send_Bit(I2Cx, STARTBIT);                                    //发送起始位

    if(result != 0) { return 1; }                                             //failure.

    /*-------------- disable read -------------*/
    FL_I2C_Master_DisableRX(I2Cx);
    /*-------------- device addr -------------*/
    result = I2C_Send_Byte(I2Cx, Devi_Addr);                                  //发送器件地址

    if(result != 0) { return 2; }                                             //failure.

    /*--------------- data addr --------------*/
    if(AddrLen == 2)
    {
        result = I2C_Send_Byte(I2Cx, (uint8_t)(Addr >> 8U));                  //发送数据地址高8位

        if(result != 0) { return 3; }                                         //failure.
    }

    result = I2C_Send_Byte(I2Cx, (uint8_t)(Addr >> 0U));                      //发送数据地址低8位

    if(result != 0) { return 3; }                                             //failure.

    if(Opt == I2CREAD)                                                        //判断是否是接收逻辑
    {
        result = I2C_Send_Bit(I2Cx, RESTARTBIT);                              //发送重起始位

        if(result != 0) { return 5; }                                         //failure.

        result = I2C_Send_Byte(I2Cx, Devi_Addr | 0x01U);                      //发送器件地址（读逻辑）

        if(result != 0) { return 5; }                                         //failure.
    }

    return 0; //ok
}

static uint8_t Wait_for_end(I2C_Type *I2Cx, uint8_t Device)
{
    uint8_t result, Devi_Addr;
    uint32_t counter = 0;
    Devi_Addr = Device;
    do
    {
        I2C_Send_Bit(I2Cx, STARTBIT);     //发送起始位
        result = I2C_Send_Byte(I2Cx, Devi_Addr);  //发送器件地址
        I2C_Send_Bit(I2Cx, STOPBIT);  //发送停止位
        counter++;
    } while((result == 0x01U) && (counter != I2C_TIMEOUT));

    if(result == 0)//设置地址成功, 写周期结束
    {
        return 0;
    }
    else
    {
        return 1; //设置地址失败,超时
    }
}

uint8_t HW_I2C_Wait_Ack(I2C_Type *I2Cx, uint32_t timeoutMs)
{
    /* 根据系统时钟计算超时周期 */
    uint32_t sysClk = FL_CMU_GetSystemClockFreq();
    uint32_t timeoutTicks = (sysClk / 1000) * timeoutMs; // 转换为时钟周期数
    
    /* 双重检测机制 */
    do {
        /* 检测NACK标志 */
        if(FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
        {
            FL_I2C_Master_ClearFlag_NACK(I2Cx);
            FL_I2C_Master_EnableI2CStop(I2Cx);
            return 1;
        }
        
        /* 检测总线空闲 */
        if(!FL_I2C_Master_IsActiveFlag_Busy(I2Cx)) 
        {
            return 0;
        }
        
    } while(timeoutTicks-- > 0);
    
    /* 超时处理 */
    FL_I2C_Master_EnableI2CStop(I2Cx);
    return 1;
}

uint8_t i2c_read(I2C_Type *I2Cx, uint8_t devAddr, uint8_t regAddr)
{
    uint8_t data = 0xFF;
    uint32_t counter = 0;
    
    /****** ????? ******/
    FL_I2C_Master_EnableI2CStart(I2Cx); // ??START
    while(!FL_I2C_Master_IsActiveFlag_Start(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT) return 0xFF;

    /****** ??????+? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, (devAddr << 1) | 0x00); // ???
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ??????? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, regAddr);
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ?????? ******/
    FL_I2C_Master_EnableI2CRestart(I2Cx); // RESTART
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_Start(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT) return 0xFF;

    /****** ??????+? ******/
    FL_I2C_Master_WriteTXBuff(I2Cx, (devAddr << 1) | 0x01); // ???
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_TXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter >= I2C_TIMEOUT || FL_I2C_Master_IsActiveFlag_NACK(I2Cx))
    {
        FL_I2C_Master_EnableI2CStop(I2Cx);
        return 0xFF;
    }
    FL_I2C_Master_ClearFlag_TXComplete(I2Cx);

    /****** ???? ******/
    FL_I2C_Master_EnableRX(I2Cx); // ??????
    FL_I2C_Master_SetRespond(I2Cx, FL_I2C_MASTER_RESPOND_NACK); // ???NACK
    
    counter = 0;
    while(!FL_I2C_Master_IsActiveFlag_RXComplete(I2Cx) && (counter++ < I2C_TIMEOUT));
    if(counter < I2C_TIMEOUT)
    {
        data = FL_I2C_Master_ReadRXBuff(I2Cx); // ????
        FL_I2C_Master_ClearFlag_RXComplete(I2Cx);
    }

    /****** ???? ******/
    FL_I2C_Master_EnableI2CStop(I2Cx); // STOP
    return data;
}

static uint8_t FT6336_WriteReg(I2C_Type *I2Cx, uint8_t reg, uint8_t value)
{
    uint8_t result;
    
    /* 发送起始位、设备地址（写）和寄存器地址 */
    result = Sendaddr(I2Cx, (FT6336_I2C_ADDR << 1), reg, 1, I2CWRITE);
    if(result != 0) return 1;
    
    /* 写入寄存器值 */
    result = I2C_Send_Byte(I2Cx, value);
    if(result != 0) return 2;
    
    /* 发送停止位 */
    I2C_Send_Bit(I2Cx, STOPBIT);
    
    return 0;
}

uint8_t FT6336_ReadReg(I2C_Type *I2Cx, uint8_t regAddr, uint8_t *value)
{
    /* 直接使用i2c_read的三参数版本 */
    *value = i2c_read(I2Cx, FT6336_I2C_ADDR, regAddr);
    return (*value == 0xFF) ? 1 : 0; // 0xFF表示读取失败
}

uint8_t FT6336_Init(I2C_Type *I2Cx)
{
    uint8_t result;
    uint8_t device_id;
    uint8_t read_back;
    /* 1. 配置设备模式 */
    result = FT6336_WriteReg(I2Cx, FT6336_REG_DEVICE_MODE, FT6336_MODE_NORMAL);
    if(result) return result;
	
    if(FT6336_ReadReg(I2Cx, FT6336_REG_DEVICE_MODE, &read_back) || 
    (read_back != FT6336_MODE_NORMAL))
    {
        return 0xE2;
    }
    /* 2. 配置中断模式 */
    result = FT6336_WriteReg(I2Cx, 0xA4, 0x00);
;
    if(result) return result;
     // 回读验证
    if(FT6336_ReadReg(I2Cx, FT6336_REG_INT_MODE, &read_back) || 
       (read_back != 0x00))
    {
        return 0xE4;
    }
    /* 3. 设置报告速率 */
    result = FT6336_WriteReg(I2Cx, FT6336_REG_RATE, FT6336_REPORT_RATE);
    if(result) return result;
    // 回读验证（可选）
    if(FT6336_ReadReg(I2Cx, FT6336_REG_RATE, &read_back) || 
       (read_back != FT6336_REPORT_RATE))
    {
        return 0xE6;
    }  
    /* 4. 验证设备ID */
		uint8_t chip_id = i2c_read(I2C1,0x38,0xA8);  
    device_id = chip_id;  
    if(device_id != 0x11) {  // FT6336的芯片ID为0x11
        return 0xFF;        // 返回无效ID错误
    }
    
    return 0; // 初始化成功
}

uint8_t i2c_read_block(I2C_Type *I2Cx, uint8_t devAddr, uint8_t regAddr, uint8_t *buf, uint8_t len)
{
    uint8_t result;
    
    /* 发送设备地址和寄存器地址 */
    result = Sendaddr(I2Cx, (devAddr << 1), regAddr, 1, I2CREAD);
    if(result != 0) return 1;

    /* 连续读取数据 */
    for(int i=0; i<len; i++) {
        if(i == len-1) {
            FL_I2C_Master_SetRespond(I2Cx, FL_I2C_MASTER_RESPOND_NACK); // 最后字节发NACK
        }
        if(I2C_Receive_Byte(I2Cx, &buf[i])) {
            I2C_Send_Bit(I2Cx, STOPBIT);
            return 2;
        }
    }
    
    I2C_Send_Bit(I2Cx, STOPBIT);
    return 0;
}

/**
  * @brief  读取单点触控坐标
  * @param  I2Cx: I2C外设
  * @param  *point: 坐标存储结构体指针
  * @retval 0=成功, 其他=错误码
  */
uint8_t FT6336_ReadTouch(I2C_Type *I2Cx, TouchPoint *point)
{
    uint8_t data[FT6336_TOUCH_DATA_LEN];
    uint8_t status;
    
    // 1. 读取状态寄存器
    if(i2c_read_block(I2Cx, FT6336_I2C_ADDR, 0x02, data, 1)) return 0xE1;
    status = data[0];

    // 2. 检查触摸点数量
    if((status & 0x0F) == 0) {
        point->valid = 0;
        return 0;
    }

    // 3. 连续读取坐标寄存器组（0x03~0x08）
    if(i2c_read_block(I2Cx, FT6336_I2C_ADDR, 0x03, data, FT6336_TOUCH_DATA_LEN)) 
        return 0xE2;

    // 4. 数据解析优化（兼容多点触控）
    point->valid = ((data[0] & 0xC0) == 0x80) &&  // XH校验
                   ((data[2] & 0xC0) == 0x80);    // YH校验
    point->x = ((data[0] & 0x0F) << 8) | data[1];
    point->y = ((data[2] & 0x0F) << 8) | data[3];
    point->event = status; // 触点ID

    return 0;
}

uint8_t pressed(I2C_Type *I2Cx, TouchPoint *point)
{
    uint8_t data[FT6336_TOUCH_DATA_LEN];
    uint8_t status;
    
    // 1. 读取状态寄存器
    if(i2c_read_block(I2Cx, FT6336_I2C_ADDR, 0x02, data, 1)) return 0xE1;
	    if((status & 0x0F) == 0) {
        return 0;
    }
    return 1;
	
}
uint8_t FT6336_ReadGest(I2C_Type *I2Cx)
{
	uint8_t gest_id = i2c_read(I2Cx,0x38,0x01);
	switch (gest_id) {
    case 0x14: 
         LCD_Fill(0,0,240,320,RED); // 处理右滑
        break;
    case 0x1C: 
         LCD_Fill(0,0,240,320,GREEN);  // 处理左滑
        break;
    default: 
        break;
}
	return 0;
}
