#include "fm33fk5xx_fl.h"
#include "vs1053.h"	
#include "spi.h"

// VS10XX默认配置参数结构体
_vs10xx_obj vsset = 
{
	220,	// 主音量：220 (范围0-254)
	6,		// 低频限幅：60Hz
	15,		// 低频增益：15dB	
	10,		// 高频限幅：10kHz	
	15,		// 高频增益：10.5dB (实际为1.5dB*值)
	0,		// 音效设置：0关闭效果	
};

// VS1053的WAV录音补丁
const uint16_t VS1053_WavPlugin[40] = {
    0x0007, 0x0001, 0x8010, 0x0006, 0x001c, 0x3e12, 0xb817, 0x3e14,
    0xf812, 0x3e01, 0xb811, 0x0007, 0x9717, 0x0020, 0xffd2, 0x0030,
    0x11d1, 0x3111, 0x8024, 0x3704, 0xc024, 0x3b81, 0x8024, 0x3101,
    0x8024, 0x3b81, 0x8024, 0x3f04, 0xc024, 0x2808, 0x4800, 0x36f1,
    0x9811, 0x0007, 0x0001, 0x8028, 0x0006, 0x0002, 0x2a00, 0x040e
};

////////////////////////////////////////////////////////////////////////////////
// VS1053 SPI接口函数

// SPI读写一个字节
// dat: 要写入的数据
// 返回值: 读取到的数据
uint8_t VS_SPI_ReadWriteByte(uint8_t dat)
{	
    uint8_t rx_data = 0;
    
    // 发送数据并读取响应
    SpiWriteAndRead(SPI1, (uint8_t)dat);
    rx_data = (uint8_t)FL_SPI_ReadRXBuff(SPI1);
    
    return rx_data;
}

// 设置SPI低速模式
void VS_SPI_SpeedLow(void)
{								 
	FL_SPI_SetBaudRate(SPI1, FL_SPI_PCLK_DIV256); // 设置低速模式 (256分频)
}

// 设置SPI高速模式
void VS_SPI_SpeedHigh(void)
{						  
	FL_SPI_SetBaudRate(SPI1, FL_SPI_PCLK_DIV16); // 设置高速模式 (64分频)
}

////////////////////////////////////////////////////////////////////////////////
// VS1053控制函数

// VS1053软复位
void VS_Soft_Reset(void)
{
	uint8_t retry = 0;
	// 等待DREQ变高（复位完成标志）
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)));
	
	VS_SPI_ReadWriteByte(0XFF); // 发送空操作字节
	
	retry = 0;
	// 检查复位是否成功 (SPI_MODE应为0x0800)
	while(VS_RD_Reg(SPI_MODE) != 0x0800)
	{
		VS_WR_Cmd(SPI_MODE, 0x0804); // 执行软复位
		FL_DelayMs(3); // 等待1.35ms
		if(retry++ > 100) break;
	}
	
	// 再次等待DREQ变高
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)));
	
	retry = 0;
	// 设置时钟频率 (SPI_CLOCKF = 0X9800)
	while(VS_RD_Reg(SPI_CLOCKF) != 0X9800)
	{
		VS_WR_Cmd(SPI_CLOCKF, 0X9800); // 3倍频, 1.5xADD
		if(retry++ > 100) break;
	}
	FL_DelayMs(20);
}

// VS1053硬复位
// 返回值: 0=成功, 1=失败
uint8_t VS_HD_Reset(void)
{
	uint8_t retry = 0;
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_7); // 复位引脚拉低
	FL_DelayMs(20);
	
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 取消片选
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_4); // 取消片选
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_7); // 复位引脚拉高
	
	// 等待DREQ变高（复位完成）
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)) && retry < 200)
	{
		retry++;
		FL_DelayUs(52);
	};
	FL_DelayMs(20);
	
	return (retry >= 200) ? 1 : 0;
}

// VS1053正弦测试（产生测试音）
void VS_Sine_Test(void)
{
	VS_HD_Reset(); // 硬复位
	VS_WR_Cmd(0x0b, 0X2020); // 设置音量
	VS_WR_Cmd(SPI_MODE, 0x0820); // 进入测试模式
	
	// 等待DREQ变高
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)));
	
	// 发送正弦测试命令
	VS_SPI_SpeedLow(); // 低速模式
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5); // 数据片选
	VS_SPI_ReadWriteByte(0x53);
	VS_SPI_ReadWriteByte(0xef);
	VS_SPI_ReadWriteByte(0x6e);
	VS_SPI_ReadWriteByte(0x24); // 频率值
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	FL_DelayMs(100);
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); 
	
	// 发送退出测试命令
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5);
	VS_SPI_ReadWriteByte(0x45);
	VS_SPI_ReadWriteByte(0x78);
	VS_SPI_ReadWriteByte(0x69);
	VS_SPI_ReadWriteByte(0x74);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	FL_DelayMs(100);
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5);
	
	// 发送新频率的正弦测试
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5);
	VS_SPI_ReadWriteByte(0x53);
	VS_SPI_ReadWriteByte(0xef);
	VS_SPI_ReadWriteByte(0x6e);
	VS_SPI_ReadWriteByte(0x44); // 新频率值
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	FL_DelayMs(100);
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5);
	
	// 再次发送退出测试命令
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5);
	VS_SPI_ReadWriteByte(0x45);
	VS_SPI_ReadWriteByte(0x78);
	VS_SPI_ReadWriteByte(0x69);
	VS_SPI_ReadWriteByte(0x74);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	FL_DelayMs(100);
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5);
}

// RAM测试
// 返回值: 测试结果 (VS1003应为0x807F, VS1053应为0X83FF)
uint16_t VS_Ram_Test(void)
{
	VS_HD_Reset(); // 硬复位
	VS_WR_Cmd(SPI_MODE, 0x0820); // 进入测试模式
	while (!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6))); // 等待DREQ变高
	VS_SPI_SpeedLow(); // 低速模式
	
	// 发送RAM测试命令
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5); // 数据片选
	VS_SPI_ReadWriteByte(0x4d);
	VS_SPI_ReadWriteByte(0xea);
	VS_SPI_ReadWriteByte(0x6d);
	VS_SPI_ReadWriteByte(0x54);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	VS_SPI_ReadWriteByte(0x00);
	FL_DelayMs(200);
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5);
	
	return VS_RD_Reg(SPI_HDAT0); // 返回测试结果
}

// 写VS10XX寄存器命令
// address: 寄存器地址
// dat: 要写入的数据
void VS_WR_Cmd(uint8_t address, uint16_t dat)
{
	// 等待DREQ变高（数据就绪）
	while((FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)) == 0);
	VS_SPI_SpeedLow(); // 低速模式
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 取消数据片选
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_4); // 使能控制片选
	
	// 发送写命令和寄存器数据
	VS_SPI_ReadWriteByte(VS_WRITE_COMMAND); // 写命令码
	VS_SPI_ReadWriteByte(address); // 寄存器地址
	VS_SPI_ReadWriteByte(dat >> 8); // 数据高字节
	VS_SPI_ReadWriteByte(dat); // 数据低字节
	
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_4); // 取消控制片选
	VS_SPI_SpeedHigh(); // 恢复高速模式
}

// 写VS10XX数据
// dat: 要写入的数据
void VS_WR_Data(uint8_t dat)
{
	VS_SPI_SpeedHigh(); // 高速模式
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5); // 使能数据片选
	VS_SPI_ReadWriteByte(dat); // 发送数据
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 取消数据片选
}

// 读VS10XX寄存器
// address: 寄存器地址
// 返回值: 读取到的数据
uint16_t VS_RD_Reg(uint8_t address)
{
	uint16_t temp = 0;
	// 等待DREQ变高
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)));
	VS_SPI_SpeedLow(); // 低速模式
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 取消数据片选
	FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_4); // 使能控制片选
	
	// 发送读命令和读取数据
	VS_SPI_ReadWriteByte(VS_READ_COMMAND); // 读命令码
	VS_SPI_ReadWriteByte(address); // 寄存器地址
	temp = VS_SPI_ReadWriteByte(0xff); // 读取高字节
	temp = temp << 8;
	temp += VS_SPI_ReadWriteByte(0xff); // 读取低字节
	
	FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_4); // 取消控制片选
	VS_SPI_SpeedHigh(); // 恢复高速模式
	return temp;
}

// 读VS1053的RAM
// addr: RAM地址
// 返回值: 读取到的数据
uint16_t VS_WRAM_Read(uint16_t addr)
{
	uint16_t res;
	VS_WR_Cmd(SPI_WRAMADDR, addr); // 设置RAM地址
	res = VS_RD_Reg(SPI_WRAM); // 读取RAM数据
	return res;
}

// 设置播放速度（仅VS1053有效）
// t: 速度值 (0=正常, 1=1倍速, 2=2倍速, 3=3倍速, 4=4倍速)
void VS_Set_Speed(uint8_t t)
{
	VS_WR_Cmd(SPI_WRAMADDR, 0X1E04); // 设置速度寄存器地址
	while(!(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6))); // 等待就绪
	VS_WR_Cmd(SPI_WRAM, t); // 写入速度值
}

const uint16_t bitrate[2][16]=
{ 
{0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0}, 
{0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0}
};

// 获取音频头信息（比特率）
// 返回值: 比特率 (bps)
uint16_t VS_Get_HeadInfo(void)
{
	unsigned int HEAD0;
	unsigned int HEAD1;
	HEAD0 = VS_RD_Reg(SPI_HDAT0);
	HEAD1 = VS_RD_Reg(SPI_HDAT1);
	
	// 根据文件类型解析比特率
	switch(HEAD1)
	{
		case 0x7665: // WAV
		case 0X4D54: // MIDI
		case 0X4154: // AAC_ADTS
		case 0X4144: // AAC_ADIF
		case 0X4D34: // AAC_MP4/M4A
		case 0X4F67: // OGG
		case 0X574D: // WMA
		case 0X664C: // FLAC
			HEAD1 = HEAD0 * 2 / 25; // 计算比特率
			if((HEAD1 % 10) > 5) return HEAD1 / 10 + 1; // 四舍五入
			else return HEAD1 / 10;
		default: // MP3
			HEAD1 >>= 3;
			HEAD1 = HEAD1 & 0x03;
			if(HEAD1 == 3) HEAD1 = 1;
			else HEAD1 = 0;
			return bitrate[HEAD1][HEAD0 >> 12]; // 从预设表获取比特率
	}
}

// 获取平均字节率
// 返回值: 平均字节率
uint32_t VS_Get_ByteRate(void)
{
	return VS_WRAM_Read(0X1E05); // 从RAM读取
}

// 获取结束填充字节
// 返回值: 结束填充字节
uint16_t VS_Get_EndFillByte(void)
{
	return VS_WRAM_Read(0X1E06); // 从RAM读取
}

// 发送音乐数据（32字节）
// buf: 数据缓冲区
// 返回值: 0=成功, 1=失败
uint8_t VS_Send_MusicData(uint8_t* buf)
{
	uint8_t n;
	if(FL_GPIO_ReadInputPort(GPIOA) & (FL_GPIO_PIN_6)) // 检查DREQ
	{
		FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5); // 使能数据片选
		for(n = 0; n < 32; n++)
		{
			VS_SPI_ReadWriteByte(buf[n]); // 发送数据
		}
		FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 取消数据片选
	}
	else return 1; // DREQ为低，未就绪
	return 0; // 发送成功
}

// 重启播放（清除缓冲区）
void VS_Restart_Play(void)
{
	uint16_t temp;
	uint16_t i;
	uint8_t n;
	uint8_t vsbuf[32];
	
	// 初始化缓冲区
	for(n = 0; n < 32; n++) vsbuf[n] = 0;
	
	// 设置取消位
	temp = VS_RD_Reg(SPI_MODE);
	temp |= 1 << 3; // 设置SM_CANCEL位
	temp |= 1 << 2; // 设置SM_LAYER12位（支持MP1/MP2）
	VS_WR_Cmd(SPI_MODE, temp);
	
	// 发送2048个零字节
	for(i = 0; i < 2048;)
	{
		if(VS_Send_MusicData(vsbuf) == 0)
		{
			i += 32;
			temp = VS_RD_Reg(SPI_MODE);
			if((temp & (1 << 3)) == 0) break; // 检查是否取消成功
		}
	}
	
	// 发送填充字节
	if(i < 2048)
	{
		temp = VS_Get_EndFillByte() & 0xff;
		for(n = 0; n < 32; n++) vsbuf[n] = temp;
		for(i = 0; i < 2052;)
		{
			if(VS_Send_MusicData(vsbuf) == 0) i += 32;
		}
	}
	else
	{
		VS_Soft_Reset(); // 取消失败，执行软复位
	}
	
	// 检查是否需要硬复位
	temp = VS_RD_Reg(SPI_HDAT0);
	temp += VS_RD_Reg(SPI_HDAT1);
	if(temp)
	{
		VS_HD_Reset(); // 硬复位
		VS_Soft_Reset(); // 软复位
	}
}

// 重置解码时间计数器
void VS_Reset_DecodeTime(void)
{
	VS_WR_Cmd(SPI_DECODE_TIME, 0x0000);
	VS_WR_Cmd(SPI_DECODE_TIME, 0x0000); // 写入两次
}

// 获取MP3解码时间（秒）
// 返回值: 解码时间（秒）
uint16_t VS_Get_DecodeTime(void)
{
	uint16_t dt = 0;
	dt = VS_RD_Reg(SPI_DECODE_TIME);
	return dt;
}

// 加载VS10XX补丁
// patch: 补丁数据指针
// len: 补丁长度
void VS_Load_Patch(uint16_t *patch, uint16_t len)
{
	uint16_t i;
	uint16_t addr, n, val;
	for(i = 0; i < len;)
	{
		addr = patch[i++];
		n = patch[i++];
		if(n & 0x8000U) // RLE压缩模式
		{
			n &= 0x7FFF;
			val = patch[i++];
			while(n--) VS_WR_Cmd(addr, val);
		}
		else // 直接复制模式
		{
			while(n--)
			{
				val = patch[i++];
				VS_WR_Cmd(addr, val);
			}
		}
	}
}

// 设置音量
// volx: 音量值 (0-254, 0最大)
void VS_Set_Vol(uint8_t volx)
{
	uint16_t volt = 0;
	volt = 254 - volx; // 左右声道音量
	volt <<= 8;
	volt += 254 - volx;
	VS_WR_Cmd(SPI_VOL, volt); // 设置音量寄存器
}

// 设置高低音
// bfreq: 低频限幅 (2-15, 单位10Hz)
// bass: 低频增益 (0-15, 单位1dB)
// tfreq: 高频限幅 (1-15, 单位kHz)
// treble: 高频增益 (0-15, 单位1.5dB)
void VS_Set_Bass(uint8_t bfreq, uint8_t bass, uint8_t tfreq, uint8_t treble)
{
	uint16_t bass_set = 0;
	signed char temp = 0;
	
	// 处理高频增益值
	if(treble == 0) temp = 0;
	else if(treble > 8) temp = treble - 8;
	else temp = treble - 9;
	
	// 组合参数值
	bass_set = temp & 0X0F;
	bass_set <<= 4;
	bass_set += tfreq & 0xf;
	bass_set <<= 4;
	bass_set += bass & 0xf;
	bass_set <<= 4;
	bass_set += bfreq & 0xf;
	
	VS_WR_Cmd(SPI_BASS, bass_set); // 设置BASS寄存器
}

// 设置音效
// eft: 0=关闭, 1=小厅, 2=大厅, 3=体育馆
void VS_Set_Effect(uint8_t eft)
{
	uint16_t temp;
	temp = VS_RD_Reg(SPI_MODE);
	if(eft & 0X01) temp |= 1 << 4; // 设置LO位
	else temp &= ~(1 << 5); // 清除LO位
	if(eft & 0X02) temp |= 1 << 7; // 设置HO位
	else temp &= ~(1 << 7); // 清除HO位
	VS_WR_Cmd(SPI_MODE, temp); // 更新模式寄存器
}

// 应用所有预设配置
void VS_Set_All(void)
{
	VS_Set_Vol(vsset.mvol);
	VS_Set_Bass(vsset.bflimit, vsset.bass, vsset.tflimit, vsset.treble);
	VS_Set_Effect(vsset.effect);
}

// MP3播放器初始化
uint8_t Mp3Player_Init(void)
{
	uint16_t ret;
	VS_HD_Reset(); // 硬复位
	VS_Set_Vol(120); // 设置初始音量
	VS_Sine_Test(); // 正弦测试
	VS_HD_Reset(); // 再次硬复位
	VS_Soft_Reset(); // 软复位
	
	VS_Load_Patch((uint16_t*)VS1053_WavPlugin, 40);
	
	return 1;
}

// 测试VS1053版本
// 返回值: 0=成功, 1=失败
uint8_t VS_Test_Version(void)
{
	uint16_t hdat0, hdat1;
	uint8_t retry = 0;
	
	if(VS_HD_Reset() != 0) return 1; // 硬复位失败
	
	hdat0 = VS_RD_Reg(SPI_HDAT0);
	hdat1 = VS_RD_Reg(SPI_HDAT1);
	
	// 检查特征值
	if(hdat0 == 0x007E && hdat1 == 0x0000) return 0;
	else return 1;
}

////////////////////////////////////////////////////////////////////////////////
// 录音功能实现

/*
函数功能：初始化WAV头
*/
void VS_RecorderWavInit(WaveHeader_t *wavhead) 
{
    wavhead->ChunkID = 0x46464952;       // "RIFF"
    wavhead->ChunkSize = 0;              // 文件总长-8，录音结束后填充
    wavhead->Format = 0x45564157;        // "WAVE"
    wavhead->Subchunk1ID = 0x20746d66;   // "fmt "
    wavhead->Subchunk1Size = 16;         // 大小为16字节
    wavhead->AudioFormat = 0x01;         // PCM格式
    wavhead->NumChannels = 1;            // 单声道
    wavhead->SampleRate = 8000;          // 8KHz采样率
    wavhead->ByteRate = 16000;// 字节率 = 采样率 * 通道数 * 样本位数/8 = 8000*1*16/8=16000
    wavhead->BlockAlign = 2;          // 块对齐 = 通道数 * 样本位数/8 = 1*16/8=2
    wavhead->BitsPerSample = 16;         // 16位PCM
    wavhead->Subchunk2ID = 0x61746164;   // "data"
    wavhead->Subchunk2Size = 0;          // 数据大小，录音结束后填充
}

/*
函数功能：激活PCM录音模式
函数参数：
        agc: 自动增益控制 (0=自动增益, 1024=1倍增益, 512=0.5倍增益, 最大65535=64倍增益)
*/
void VS_RecorderInit(uint16_t agc)
{
    // 设置相关寄存器
    VS_WR_Cmd(SPI_BASS, 0x0000);          // 关闭音效
    VS_WR_Cmd(SPI_AICTRL0, 8000);         // 设置采样率为8KHz
    VS_WR_Cmd(SPI_AICTRL1, agc);          // 设置自动增益控制
    VS_WR_Cmd(SPI_AICTRL2, 0);            // 设置最大增益
    VS_WR_Cmd(SPI_AICTRL3, 6);            // 左通道（MIC单声道输入）
    VS_WR_Cmd(SPI_CLOCKF, 0x2000);        // 设置时钟：2倍频，12.288MHz
		VS_WR_Cmd(SPI_MODE, 0x1804);          // 激活MIC录音模式 
		FL_DelayMs(5);
    // 加载WAV录音补丁
    VS_Load_Patch((uint16_t*)VS1053_WavPlugin, 40);
}

uint16_t VS_Read_RawData(void) {
    uint16_t data;
    while(!(FL_GPIO_ReadInputPort(GPIOA) & FL_GPIO_PIN_6)); // 等待DREQ变高
    
    VS_SPI_SpeedHigh(); // 高速模式
    FL_GPIO_ResetOutputPin(GPIOA, FL_GPIO_PIN_5); // 拉低XDCS（数据片选）
    
    // 读取16位PCM数据
    data = VS_SPI_ReadWriteByte(0xFF) << 8; // 高字节
    data |= VS_SPI_ReadWriteByte(0xFF);     // 低字节
    
    FL_GPIO_SetOutputPin(GPIOA, FL_GPIO_PIN_5); // 释放XDCS
    return data;
}

/*
函数功能：读取录音数据（PCM格式）
返回值：16位PCM数据
*/
uint16_t VS_Read_RecData(void)
{
    // 等待DREQ变高（数据就绪）
    while(!(FL_GPIO_ReadInputPort(GPIOA) & FL_GPIO_PIN_6));
    
    // 读取HDAT0和HDAT1寄存器获取录音数据
    uint16_t hdat0 = VS_RD_Reg(SPI_HDAT0);
//    uint16_t hdat1 = VS_RD_Reg(SPI_HDAT1);
    
    // 返回PCM数据（这里返回左声道数据）
    return hdat0; // 单声道录音，左声道数据在HDAT0
}

/*
函数功能：开始录音
*/
void VS_Start_Recording(void)
{
    // 重置解码时间计数器
    VS_Reset_DecodeTime();
    
    // 设置录音模式
    VS_WR_Cmd(SPI_MODE, VS_RD_Reg(SPI_MODE) | 0x1804);
    
    // 清除任何可能存在的旧数据
    while(FL_GPIO_ReadInputPort(GPIOA) & FL_GPIO_PIN_6) {
        (void)VS_RD_Reg(SPI_HDAT0);
        (void)VS_RD_Reg(SPI_HDAT1);
    }
}

/*
函数功能：停止录音
*/
void VS_Stop_Recording(void)
{
    // 清除录音模式位
    VS_WR_Cmd(SPI_MODE, VS_RD_Reg(SPI_MODE) & ~0x1804);
}
