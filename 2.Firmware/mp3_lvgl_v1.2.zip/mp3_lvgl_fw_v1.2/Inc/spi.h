#ifndef __SPI_H__
#define __SPI_H__

#include "fm33fk5xx_fl.h"

uint32_t SpiWriteAndRead(SPI_Type *SPIx, uint32_t data);
void SpiWriteData(SPI_Type *SPIx, uint8_t *data, uint16_t length);
void SpiReadData(SPI_Type *SPIx, uint8_t *data, uint16_t length);

#endif
