#include "main.h"
#include "EPSC.h"
#include "mf_config.h"
#include "I2C.h"
#include "touch.h"
#include "lv_port_disp.h"
#include "lv_port_indev.h"
#include "lv_port_fs.h"
#include "lv_conf.h"
#include "SDdriver.h"
#include "ff.h"
#include "diskio.h"
#include "lv_port_indev.h"
#include "homepage.h"
#include "ds1302.h"
#include "clock.h"
#include "vs1053.h"	
#include "audio.h"
#include "style.h"
//tcs --> pb8
// ????????
#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320
MSD_CARDINFO cardInfo;
FATFS fs;
FIL fil;      // 文件对象
uint8_t tbuf[512]; // 数据缓冲区
lv_obj_t *label;  // 全局标签指针

int main(void)
{
	  FRESULT res;
		uint16_t br;
		uint8_t min=0;
		int ret =1;
    MF_Clock_Init();
		FL_Init();
		FL_DelayMs(500);
	
    MF_Config_Init();	
		FT6336_Init(I2C1);

		uint8_t buf[4];
		FL_DelayMs(500);
		disk_initialize(0);
		f_mount(&fs, "0:", 1);
		init_playlist("0:/MUSIC/");
		FL_DelayMs(500);
    LCD_Config();
	
		LCD_DisplayOn();
		LCD_Fill(0,0,240,320,BLACK);
		Mp3Player_Init();
//		ds1032_init();
		
		lv_init();
		lv_port_disp_init();
	  lv_port_indev_init();	
  	lv_port_fs_init();	
		GPTIM0_Init();
		FL_DelayMs(1000);

		GPTIM1_Init();
		min=TimeData.minute;
		init_global_styles();
		clock_alarm();
		
    while(1)
    {
			lv_task_handler();
			update_clock_from_rtc();		

  }

}
