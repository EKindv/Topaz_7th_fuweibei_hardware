#ifndef __I2C_H__
#define __I2C_H__

#include "fm33fk5xx_fl.h"

#define FT6336_I2C_ADDR         0x38        // 7?????
#define FT6336_REG_DEVICE_MODE  0x00        // ???????
#define FT6336_REG_ID           0xA8        // ??ID???
#define FT6336_REG_INT_MODE     0xA4        // ???????
#define FT6336_REG_RATE         0x88        // ???????
#define I2C_READ_TIMEOUT   1000 

#define FT6336_REG_DEVICE_MODE  0x00
#define FT6336_REG_INT_MODE     0xA4
#define FT6336_REG_RATE         0x88
/* ??????? */
#define FT6336_MODE_NORMAL      0x00        // ??????
#define FT6336_INT_MODE_TRIGGER 0x01        // ??????
#define FT6336_REPORT_RATE      0x0D        // ??????

#define FT6336_REG_TD_STATUS    0x02    // ???????
#define FT6336_REG_P1_XH        0x03    // ??1 X?????
#define FT6336_REG_P1_XL        0x04    // ??1 X?????
#define FT6336_REG_P1_YH        0x05    // ??1 Y?????
#define FT6336_REG_P1_YL        0x06    // ??1 Y?????
#define FT6336_REG_P2_XH        0x09    // ??2 X?????(?????)

#define FT6336_TOUCH_DATA_LEN 6 // 0x03~0x08(????)

typedef struct {
    uint16_t x;
    uint16_t y;
    uint8_t  event;  // ????(0: ?? 1: ??)
    uint8_t  valid;  // ?????
} TouchPoint;

extern uint8_t I2CWriteAndRead(void);
uint8_t I2C_Send_Byte(I2C_Type *I2Cx, uint8_t x_byte);
uint8_t i2c_read(I2C_Type *I2Cx, uint8_t devAddr, uint8_t regAddr);
uint8_t FT6336_Init(I2C_Type *I2Cx);
uint8_t FT6336_ReadTouch(I2C_Type *I2Cx, TouchPoint *point);
uint8_t pressed(I2C_Type *I2Cx, TouchPoint *point);
uint8_t FT6336_ReadGest(I2C_Type *I2Cx);

#endif
