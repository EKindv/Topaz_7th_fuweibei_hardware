#ifndef __AUDIO_H__
#define __AUDIO_H__

#include "lvgl.h"
#include "stdlib.h"
#include "ff.h"
#include "stdio.h"

#define VOL_ICON_MARKER (void*)0x55AA
extern char fileList[8][256]; // ?????????
extern lv_obj_t *music_player_screen;

void create_music_player(void);
void init_playlist(const char* path);
void play_next_song();
void play_prev_song();
void audio_player_task(void);
void create_song_menu();

#endif
