#ifndef __MIC_H__
#define __MIC_H__
#include "lvgl.h"

extern lv_obj_t *mic_screen;
extern lv_obj_t *status_label;     // ??????
extern lv_obj_t *time_label;       // ????


void create_recorder_ui();
void update_recording_state(bool is_recording);
void update_recording_time(uint32_t seconds);
static void recoder_back_action(lv_obj_t *btn, lv_event_t event);

	
#endif
