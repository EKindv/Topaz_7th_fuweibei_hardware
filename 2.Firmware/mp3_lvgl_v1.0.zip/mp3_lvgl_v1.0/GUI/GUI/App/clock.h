#ifndef __CLOCK_H__
#define __CLOCK_H__

#include "lvgl.h"
#include "stdlib.h"

extern lv_obj_t *clock_screen;
extern lv_obj_t *current_screen;
extern lv_obj_t *home_screen;

void clock_alarm(void);
void update_clock_from_rtc(void);
	

#endif
